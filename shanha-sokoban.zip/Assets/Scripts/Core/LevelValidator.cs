﻿using System.Collections.Generic;
using UnityEngine;

namespace ShanHaiSokoban
{
    public enum SolvableResult
    {
        Solvable,
        Unsolvable,
        Unknown, 
    }
    public static class LevelValidator
    {
       
        public static List<string> Check(CellType[,] grid)
        {
            var issues = new List<string>();
            int h = grid.GetLength(0), w = grid.GetLength(1);
            if (h < 3 || w < 3)
            {
                issues.Add("棋盘至少需要 3×3");
                return issues;
            }

            int playerCount = 0, boxCount = 0, targetCount = 0;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    CellType t = grid[y, x];
                    if (SokobanLevel.IsPlayerCell(t)) playerCount++;
                    if (SokobanLevel.IsBoxCell(t)) boxCount++;
                    if (SokobanLevel.IsTargetCell(t)) targetCount++;
                }
            }
            if (playerCount == 0) issues.Add("缺少玩家（@）");
            else if (playerCount > 1) issues.Add("玩家只能有一个");
            if (targetCount == 0) issues.Add("缺少目标点（.）");
            if (boxCount != targetCount) issues.Add($"箱子数（{boxCount}）与目标点数（{targetCount}）不一致");
            return issues;
        }

        public static SolvableResult IsSolvable(CellType[,] grid, int maxStates = 300000)
        {
            int h = grid.GetLength(0), w = grid.GetLength(1);

            int px = -1, py = -1;
            var boxes = new List<int>();
            var targets = new HashSet<int>();
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    CellType t = grid[y, x];
                    int idx = y * w + x;
                    if (SokobanLevel.IsPlayerCell(t)) { px = x; py = y; }
                    if (SokobanLevel.IsBoxCell(t)) boxes.Add(idx);
                    if (SokobanLevel.IsTargetCell(t)) targets.Add(idx);
                }
            }
            if (px < 0 || boxes.Count == 0 || boxes.Count != targets.Count) return SolvableResult.Unsolvable;

            boxes.Sort();
            string Key(int p, List<int> bs)
            {
                var sb = new System.Text.StringBuilder(64);
                sb.Append(p).Append('|');
                for (int i = 0; i < bs.Count; i++) { if (i > 0) sb.Append(','); sb.Append(bs[i]); }
                return sb.ToString();
            }

            var queue = new Queue<(int p, List<int> bs)>();
            var visited = new HashSet<string>();
            int start = py * w + px;
            queue.Enqueue((start, new List<int>(boxes)));
            visited.Add(Key(start, boxes));

            int[] dirs = { 1, -1, w, -w };
            while (queue.Count > 0)
            {
                if (visited.Count > maxStates) return SolvableResult.Unknown;
                var (p, bs) = queue.Dequeue();
                int bx = p % w, by = p / w;
                for (int i = 0; i < 4; i++)
                {
                    int d = dirs[i];
                    int n = p + d;
                    if (n < 0 || n >= w * h) continue;
                   
                    int nx = n % w, ny = n / w;
                    if (System.Math.Abs(nx - bx) > 1) continue;
                    if (grid[ny, nx] == CellType.Wall || grid[ny, nx] == CellType.Obstacle) continue;

                    int bi = bs.IndexOf(n);
                    if (bi >= 0)
                    {
                        int nn = n + d;
                        if (nn < 0 || nn >= w * h) continue;
                        int nnx = nn % w, nny = nn / w;
                        if (System.Math.Abs(nnx - nx) > 1) continue;
                        if (grid[nny, nnx] == CellType.Wall || grid[nny, nnx] == CellType.Obstacle) continue;
                        if (bs.Contains(nn)) continue;

                        var nb = new List<int>(bs);
                        nb[bi] = nn;
                        nb.Sort();
                        bool win = true;
                        for (int k = 0; k < nb.Count; k++)
                            if (!targets.Contains(nb[k])) { win = false; break; }
                        if (win) return SolvableResult.Solvable;

                        string nk = Key(n, nb);
                        if (visited.Add(nk)) queue.Enqueue((n, nb));
                    }
                    else
                    {
                        string nk = Key(n, bs);
                        if (visited.Add(nk)) queue.Enqueue((n, bs));
                    }
                }
            }
            return SolvableResult.Unsolvable;
        }

        public static string SolvableText(SolvableResult r)
        {
            switch (r)
            {
                case SolvableResult.Solvable: return "可解 ✓";
                case SolvableResult.Unsolvable: return "不可解 ✗";
                default: return "状态空间过大，无法判定";
            }
        }
    }
}
