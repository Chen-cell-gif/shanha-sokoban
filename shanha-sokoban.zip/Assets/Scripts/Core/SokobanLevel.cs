﻿using System;
using UnityEngine;

namespace ShanHaiSokoban
{
    public enum CellType : byte
    {
        Empty = 0,          
        Wall = 1,           
        Floor = 2,          
        Box = 3,            
        Target = 4,         
        Player = 5,         
        BoxOnTarget = 6,    
        PlayerOnTarget = 7, 
        Obstacle = 8,       
        Trap = 9,         
    }
    [Serializable]
    public class LevelData
    {
        public string name;
        public string[] rows;
    }
    public static class SokobanLevel
    {
        public const char Wall = '#';
        public const char Floor = ' ';
        public const char Box = '$';
        public const char Target = '.';
        public const char Player = '@';
        public const char BoxOnTarget = '*';
        public const char PlayerOnTarget = '+';
        public const char Obstacle = 'X';  
        public const char Trap = '!';       

 
        public static CellType[,] ParseRows(string[] rows)
        {
            if (rows == null || rows.Length == 0) return new CellType[0, 0];
            int h = rows.Length;
            int w = 0;
            for (int y = 0; y < h; y++)
                if (rows[y] != null && rows[y].Length > w) w = rows[y].Length;
            if (w == 0) return new CellType[0, 0];

            var grid = new CellType[h, w];
            for (int y = 0; y < h; y++)
            {
                string line = rows[y] ?? string.Empty;
                for (int x = 0; x < w; x++)
                {
                    char c = x < line.Length ? line[x] : Wall;
                    grid[y, x] = CharToCell(c);
                }
            }
            return grid;
        }

        public static CellType CharToCell(char c)
        {
            switch (c)
            {
                case Wall: return CellType.Wall;
                case Box: return CellType.Box;
                case Target: return CellType.Target;
                case Player: return CellType.Player;
                case BoxOnTarget: return CellType.BoxOnTarget;
                case PlayerOnTarget: return CellType.PlayerOnTarget;
                case Obstacle: return CellType.Obstacle;
                case Trap: return CellType.Trap;
                default: return CellType.Floor;
            }
        }

        public static char CellToChar(CellType t)
        {
            switch (t)
            {
                case CellType.Wall: return Wall;
                case CellType.Box: return Box;
                case CellType.Target: return Target;
                case CellType.Player: return Player;
                case CellType.BoxOnTarget: return BoxOnTarget;
                case CellType.PlayerOnTarget: return PlayerOnTarget;
                case CellType.Obstacle: return Obstacle;
                case CellType.Trap: return Trap;
                default: return Floor;
            }
        }

       
        public static string[] ToRows(CellType[,] grid)
        {
            int h = grid.GetLength(0), w = grid.GetLength(1);
            var rows = new string[h];
            for (int y = 0; y < h; y++)
            {
                var sb = new System.Text.StringBuilder(w);
                for (int x = 0; x < w; x++) sb.Append(CellToChar(grid[y, x]));
                rows[y] = sb.ToString();
            }
            return rows;
        }

        public static CellType[,] CloneGrid(CellType[,] src)
        {
            int h = src.GetLength(0), w = src.GetLength(1);
            var dst = new CellType[h, w];
            Buffer.BlockCopy(src, 0, dst, 0, h * w * sizeof(byte));
            return dst;
        }

        public static bool InBounds(CellType[,] g, int x, int y)
        {
            return x >= 0 && y >= 0 && x < g.GetLength(1) && y < g.GetLength(0);
        }

        public static bool IsBoxCell(CellType t)
        {
            return t == CellType.Box || t == CellType.BoxOnTarget;
        }

        public static bool IsPlayerCell(CellType t)
        {
            return t == CellType.Player || t == CellType.PlayerOnTarget;
        }

        public static bool IsTargetCell(CellType t)
        {
            return t == CellType.Target || t == CellType.BoxOnTarget || t == CellType.PlayerOnTarget;
        }

        public static bool IsObstacleCell(CellType t)
        {
            return t == CellType.Obstacle;
        }

        public static bool IsTrapCell(CellType t)
        {
            return t == CellType.Trap;
        }
    }
}
