﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ShanHaiSokoban
{
    
    public enum MoveResult
    {
        None,    
        Blocked,
        Moved,   
        Pushed, 
        Win,     
        Trapped,
    }
    public class SokobanGame
    {
        public int Width { get; private set; }
        public int Height { get; private set; }

        
        public CellType[,] Grid;

        public int PlayerX { get; private set; }
        public int PlayerY { get; private set; }
        public int Moves { get; private set; }  
        public int Pushes { get; private set; }  

        private readonly HashSet<int> targets = new HashSet<int>();
        private readonly HashSet<int> boxes = new HashSet<int>();
        private readonly HashSet<int> traps = new HashSet<int>();
        private readonly List<Snapshot> history = new List<Snapshot>();

        private struct Snapshot
        {
            public int px, py, moves, pushes;
            public int[] boxes;
        }

        public int BoxCount { get { return boxes.Count; } }
        public int TargetCount { get { return targets.Count; } }
        public bool HasPlayer { get { return PlayerX >= 0 && PlayerY >= 0; } }

        public SokobanGame(CellType[,] grid)
        {
            Grid = grid;
            RebuildState();
        }
        public void RebuildState()
        {
            Height = Grid.GetLength(0);
            Width = Grid.GetLength(1);
            targets.Clear();
            boxes.Clear();
            traps.Clear();
            PlayerX = -1;
            PlayerY = -1;
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    CellType t = Grid[y, x];
                    if (SokobanLevel.IsTargetCell(t)) targets.Add(y * Width + x);
                    if (SokobanLevel.IsBoxCell(t)) boxes.Add(y * Width + x);
                    if (SokobanLevel.IsPlayerCell(t)) { PlayerX = x; PlayerY = y; }
                    if (SokobanLevel.IsTrapCell(t)) traps.Add(y * Width + x);
                }
            }
        }

        public bool IsWin
        {
            get
            {
                if (targets.Count == 0 || boxes.Count == 0) return false;
                return boxes.SetEquals(targets);
            }
        }

        public bool IsBoxAt(int x, int y)
        {
            return SokobanLevel.InBounds(Grid, x, y) && SokobanLevel.IsBoxCell(Grid[y, x]);
        }

        public bool IsTargetAt(int x, int y)
        {
            return targets.Contains(y * Width + x);
        }

        public bool IsTrapAt(int x, int y)
        {
            return traps.Contains(y * Width + x);
        }
        public MoveResult TryMove(int dx, int dy)
        {
            if (!HasPlayer) return MoveResult.Blocked;
            int nx = PlayerX + dx;
            int ny = PlayerY + dy;
            if (!SokobanLevel.InBounds(Grid, nx, ny)) return MoveResult.Blocked;
            if (Grid[ny, nx] == CellType.Wall || Grid[ny, nx] == CellType.Obstacle) return MoveResult.Blocked;

            if (IsBoxAt(nx, ny))
            {
                int nnx = nx + dx;
                int nny = ny + dy;
                if (!SokobanLevel.InBounds(Grid, nnx, nny)) return MoveResult.Blocked;
                if (Grid[nny, nnx] == CellType.Wall || Grid[nny, nnx] == CellType.Obstacle
                    || Grid[nny, nnx] == CellType.Trap || IsBoxAt(nnx, nny)) return MoveResult.Blocked;

                PushSnapshot();
                MoveBox(nx, ny, nnx, nny);
                MovePlayer(nx, ny);
                Pushes++;
                Moves++;
                return IsWin ? MoveResult.Win : MoveResult.Pushed;
            }

            PushSnapshot();
            MovePlayer(nx, ny);
            Moves++;
            if (IsTrapAt(nx, ny)) return MoveResult.Trapped;
            return MoveResult.Moved;
        }
        public bool Undo()
        {
            if (history.Count == 0) return false;
            Snapshot s = history[history.Count - 1];
            history.RemoveAt(history.Count - 1);
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    CellType t = Grid[y, x];
                    if (SokobanLevel.IsBoxCell(t) || SokobanLevel.IsPlayerCell(t))
                        Grid[y, x] = IsTargetAt(x, y) ? CellType.Target : CellType.Floor;
                }
            }
            boxes.Clear();
            for (int i = 0; i < s.boxes.Length; i++)
            {
                int idx = s.boxes[i];
                int bx = idx % Width, by = idx / Width;
                Grid[by, bx] = IsTargetAt(bx, by) ? CellType.BoxOnTarget : CellType.Box;
                boxes.Add(idx);
            }
            PlayerX = s.px; PlayerY = s.py;
            Grid[PlayerY, PlayerX] = IsTargetAt(PlayerX, PlayerY) ? CellType.PlayerOnTarget : CellType.Player;
            Moves = s.moves;
            Pushes = s.pushes;
            return true;
        }
        public bool PlayerOnTarget { get { return IsTargetAt(PlayerX, PlayerY); } }

        private void PushSnapshot()
        {
            var arr = new int[boxes.Count];
            int i = 0;
            foreach (int idx in boxes) arr[i++] = idx;
            history.Add(new Snapshot { px = PlayerX, py = PlayerY, moves = Moves, pushes = Pushes, boxes = arr });
        }

        private void MoveBox(int fx, int fy, int tx, int ty)
        {
            
            Grid[fy, fx] = IsTargetAt(fx, fy) ? CellType.Target : CellType.Floor;
            boxes.Remove(fy * Width + fx);
           
            Grid[ty, tx] = IsTargetAt(tx, ty) ? CellType.BoxOnTarget : CellType.Box;
            boxes.Add(ty * Width + tx);
        }

        private void MovePlayer(int nx, int ny)
        {
           
            Grid[PlayerY, PlayerX] = IsTargetAt(PlayerX, PlayerY) ? CellType.Target : CellType.Floor;
            PlayerX = nx;
            PlayerY = ny;
            Grid[ny, nx] = IsTargetAt(nx, ny) ? CellType.PlayerOnTarget : CellType.Player;
        }
        public void RestoreCounters(int moves, int pushes)
        {
            Moves = moves;
            Pushes = pushes;
            history.Clear();   
        }
        public LevelData ToLevelData(string name)
        {
            return new LevelData { name = name, rows = SokobanLevel.ToRows(Grid) };
        }
    }
}
