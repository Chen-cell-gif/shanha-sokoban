#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ShanHaiSokoban.EditorTools
{
    
    public static class AutoNav
    {
        private static int phase;
        private static double t0;

        public static void Run()
        {
            EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity");
            phase = 0;
            t0 = 0;
            EditorApplication.update += Tick;
        }

        private static void Tick()
        {
            double now = EditorApplication.timeSinceStartup;
            if (phase == 0)
            {
                t0 = now;
                phase = 1;
                EditorApplication.EnterPlaymode();
                Debug.Log("[AutoNav] 进入 Play");
                return;
            }
            var ui = Object.FindObjectOfType<UIManager>();
            if (ui == null)
            {
                if (now - t0 > 8) { Debug.LogError("[AutoNav] 未找到 UIManager，中止"); Finish(); }
                return;
            }
            switch (phase)
            {
                case 1:
                    if (now - t0 < 2) return;
                    ui.ShowLevelSelect();
                    phase = 2; t0 = now;
                    Debug.Log("[AutoNav] 打开选关");
                    break;
                case 2:
                    if (now - t0 < 1) return;
                    {
                        var grid = GameObject.Find("LevelGrid");
                        if (grid == null) { Debug.LogError("[AutoNav] LevelGrid 不存在"); }
                        else
                        {
                            int n = 0;
                            foreach (Transform ch in grid.transform)
                                if (ch.name.StartsWith("Lv_builtin")) n++;
                            Debug.Log("[AutoNav] LevelGrid 内置按钮数=" + n);
                            var btn1 = grid.transform.Find("Lv_builtin_1");
                            if (btn1 != null)
                            {
                                var b = btn1.GetComponent<Button>();
                                if (b != null)
                                {
                                    ExecuteEvents.Execute(b.gameObject,
                                        new PointerEventData(EventSystem.current),
                                        ExecuteEvents.pointerClickHandler);
                                    Debug.Log("[AutoNav] 点击第1关按钮");
                                }
                            }
                        }
                    }
                    phase = 3; t0 = now;
                    break;
                case 3:
                    if (now - t0 < 1.5) return;
                    Debug.Log("[AutoNav] 当前面板 Game=" + (GameObject.Find("GamePanel") != null && GameObject.Find("GamePanel").activeSelf));
                    ui.ShowEditor();
                    phase = 4; t0 = now;
                    break;
                case 4:
                    if (now - t0 < 1) return;
                    {
                        var ed = Object.FindObjectOfType<LevelEditorController>();
                        if (ed != null)
                        {
                            ed.SaveNow(); 
                            Debug.Log("[AutoNav] SaveNow 调用完成");
                        }
                        var sd = GameObject.Find("SaveDialog");
                        Debug.Log("[AutoNav] SaveDialog 对象=" + (sd != null ? "存在" : "缺失"));
                    }
                    phase = 5; t0 = now;
                    break;
                case 5:
                    if (now - t0 < 1.5) return;
                    Debug.Log("[AutoNav] 全部步骤完成");
                    Finish();
                    break;
            }
        }

        private static void Finish()
        {
            EditorApplication.ExitPlaymode();
            EditorApplication.update -= Tick;
            EditorApplication.update += QuitSoon;
        }

        private static void QuitSoon()
        {
            EditorApplication.update -= QuitSoon;
            EditorApplication.Exit(0);
        }
    }
}
#endif
