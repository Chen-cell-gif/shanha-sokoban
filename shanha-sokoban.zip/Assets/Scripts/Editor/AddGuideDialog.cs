#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ShanHaiSokoban.EditorTools
{
    
    public static class AddGuideDialog
    {
        public const string BoxPath = "Assets/山海机巧录/裁剪后的ui/18cc731c74ad9381433b97fb1623a76c.png";
        public const string PortraitPath = "Assets/山海机巧录/ui背景/组装界面/驾驶室.png";

        [MenuItem("Tools/增量添加退出按钮与关前引导对话框")]
        public static void RunFromMenu() { Run(); }

        public static void RunAndQuit()
        {
            Run();
            EditorApplication.Exit(0);
        }

        public static void Run()
        {
            var scene = EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity");
            var canvas = GameObject.Find("UICanvas");
            if (canvas == null)
            {
                Debug.LogError("[AddGuideDialog] 场景中未找到 UICanvas，中止");
                return;
            }

            var rb = canvas.AddComponent<ResourceBank>();
            rb.EnsureLoaded();

            var box = LoadSprite(BoxPath);
            var portrait = LoadSprite(PortraitPath);
            if (box == null || portrait == null)
            {
                Debug.LogError("[AddGuideDialog] 对话框/人物图片加载失败");
                Object.DestroyImmediate(rb);
                return;
            }

            var menu = canvas.transform.Find("MainMenu");
            if (menu != null) UIManager.AddExitButtonIfMissing(menu);
            else Debug.LogWarning("[AddGuideDialog] 未找到 MainMenu，跳过退出按钮");

            UIManager.AddGuideDialogIfMissing(canvas.transform, box, portrait);

            Object.DestroyImmediate(rb);
            EditorSceneManager.SaveScene(scene);
            Debug.Log("[AddGuideDialog] 增量添加完成（已有内容全部保留）");
        }

        private static Sprite LoadSprite(string path)
        {
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null && importer.textureType != TextureImporterType.Sprite)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
                Debug.Log("[AddGuideDialog] 已将该图片设为 Sprite：" + path);
            }
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }
    }
}
#endif
