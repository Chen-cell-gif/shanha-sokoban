﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban.EditorTools
{
  
    public static class SetLevelButtonSprites
    {
        [MenuItem("Tools/更新第4与第5关按钮底图")]
        public static void RunFromMenu()
        {
            Run();
        }

        public static void RunAndQuit()
        {
            Run();
            EditorApplication.Exit(0);
        }

        public static void Run()
        {
            var scene = EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity");
            var canvas = GameObject.Find("UICanvas");
            if (canvas == null) { Debug.LogError("[SetLevelButtonSprites] 未找到 UICanvas"); return; }
            var rb = canvas.AddComponent<ResourceBank>();
            rb.EnsureLoaded();

            var grid = canvas.transform.Find("LevelSelect/LevelGrid");
            if (grid == null) { Debug.LogError("[SetLevelButtonSprites] 未找到 LevelGrid"); return; }

            Apply(grid, "Lv_builtin_4", rb.BtnLevel4);
            Apply(grid, "Lv_builtin_5", rb.BtnLevel5);

            Object.DestroyImmediate(rb);
            EditorSceneManager.SaveScene(scene);
            Debug.Log("[SetLevelButtonSprites] 第4/5关按钮底图已更新");
        }

        private static void Apply(Transform grid, string name, Sprite spr)
        {
            var t = grid.Find(name);
            if (t == null) { Debug.LogWarning("[SetLevelButtonSprites] 未找到 " + name); return; }
            var img = t.GetComponent<Image>();
            if (img != null) img.sprite = spr;
            Debug.Log("[SetLevelButtonSprites] " + name + " -> " + (spr != null ? spr.name : "null"));
        }
    }
}
#endif
