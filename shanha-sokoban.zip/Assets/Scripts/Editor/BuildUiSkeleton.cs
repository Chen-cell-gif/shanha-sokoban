﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban.EditorTools
{
    
    public static class BuildUiSkeleton
    {
        private static readonly string[] PanelNames =
        {
            "MainMenu", "LevelSelect", "GamePanel", "EditorPanel",
            "WinPanel", "PausePanel", "ToastHost"
        };

       
        [MenuItem("Tools/生成UI骨架")]
        public static void RunFromMenu()
        {
            Run();
        }

       
        public static void RunAndQuit()
        {
            Run();
            EditorApplication.Exit(0);
        }

        public static void Run()
        {
            var scene = EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity");

            var old = GameObject.Find("UICanvas");
            if (old != null) Object.DestroyImmediate(old);

            var canvasGo = new GameObject("UICanvas", typeof(RectTransform), typeof(Canvas),
                                          typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.layer = 5;
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.pixelPerfect = false;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            foreach (var name in PanelNames)
                MakePanel(canvasGo.transform, name);

            BakeContent(canvasGo);

            EditorSceneManager.SaveScene(scene);
            Debug.Log("[BuildUiSkeleton] 已生成 UICanvas、" + PanelNames.Length + " 个面板及完整 UI 内容");
        }

      
        private static void BakeContent(GameObject canvasGo)
        {
            var rb = canvasGo.AddComponent<ResourceBank>();
            rb.EnsureLoaded();
            var ui = canvasGo.AddComponent<UIManager>();
            ui.BakeAll();
            Object.DestroyImmediate(ui);
            Object.DestroyImmediate(rb);
        }

        private static void MakePanel(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5;
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(1920, 1080);
        }
    }
}
#endif
