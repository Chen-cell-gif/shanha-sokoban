﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ShanHaiSokoban.EditorTools
{
   
    public static class AddUiPanels
    {
        [MenuItem("Tools/增量添加选关网格与保存对话框")]
        public static void RunFromMenu()
        {
            Run();
        }

        public static void RunAndQuit()
        {
            Run();
            EditorApplication.Exit(0);
        }

        public static void Run()
        {
            var scene = EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity");
            var canvas = GameObject.Find("UICanvas");
            if (canvas == null)
            {
                Debug.LogError("[AddUiPanels] 场景中未找到 UICanvas，中止");
                return;
            }

            var rb = canvas.AddComponent<ResourceBank>();
            rb.EnsureLoaded();

            var select = canvas.transform.Find("LevelSelect");
            if (select != null) UIManager.AddLevelGridIfMissing(select);
            else Debug.LogWarning("[AddUiPanels] 未找到 LevelSelect，跳过选关网格");

            var editor = canvas.transform.Find("EditorPanel");
            if (editor != null) UIManager.AddSaveDialogIfMissing(editor);
            else Debug.LogWarning("[AddUiPanels] 未找到 EditorPanel，跳过保存对话框");

            Object.DestroyImmediate(rb);
            EditorSceneManager.SaveScene(scene);
            Debug.Log("[AddUiPanels] 增量添加完成（已有内容全部保留）");
        }
    }
}
#endif
