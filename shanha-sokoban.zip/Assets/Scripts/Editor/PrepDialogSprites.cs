#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace ShanHaiSokoban.EditorTools
{
    
    public static class PrepDialogSprites
    {
        public static readonly string[] Paths =
        {
            "Assets/Resources/UI/dialog_box.png",
            "Assets/Resources/UI/guide_portrait.png",
        };

        public static void RunAndQuit()
        {
            foreach (var path in Paths)
            {
                var imp = AssetImporter.GetAtPath(path) as TextureImporter;
                if (imp == null) { Debug.LogError("[PrepDialogSprites] 未找到 " + path); continue; }
                imp.textureType = TextureImporterType.Sprite;
                imp.spriteImportMode = SpriteImportMode.Single;
                imp.mipmapEnabled = false;
                imp.alphaIsTransparency = true;
                imp.SaveAndReimport();
                Debug.Log("[PrepDialogSprites] 已设为 Sprite：" + path);
            }
            AssetDatabase.Refresh();
            Debug.Log("[PrepDialogSprites] 完成");
            EditorApplication.Exit(0);
        }
    }
}
#endif
