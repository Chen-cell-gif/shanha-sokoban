﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace ShanHaiSokoban.EditorTools
{
    
    public static class SetSpriteImports
    {
        [MenuItem("Tools/资源纹理设为Sprite")]
        public static void RunFromMenu()
        {
            Run();
        }

        public static void RunAndQuit()
        {
            Run();
            EditorApplication.Exit(0);
        }

        public static void Run()
        {
            int n = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { "Assets/Resources" }))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (!path.EndsWith(".png") && !path.EndsWith(".jpg")) continue;
                var imp = AssetImporter.GetAtPath(path) as TextureImporter;
                if (imp == null) continue;
                bool changed = false;
                if (imp.textureType != TextureImporterType.Sprite) { imp.textureType = TextureImporterType.Sprite; changed = true; }
                if (imp.spriteImportMode != SpriteImportMode.Single) { imp.spriteImportMode = SpriteImportMode.Single; changed = true; }
                if (imp.filterMode != FilterMode.Point) { imp.filterMode = FilterMode.Point; changed = true; }
                if (imp.mipmapEnabled) { imp.mipmapEnabled = false; changed = true; }
                if (!imp.alphaIsTransparency) { imp.alphaIsTransparency = true; changed = true; }
                if (imp.textureCompression != TextureImporterCompression.Uncompressed)
                {
                    imp.textureCompression = TextureImporterCompression.Uncompressed;
                    changed = true;
                }
                if (changed)
                {
                    imp.SaveAndReimport();
                    n++;
                }
            }
            Debug.Log("[SetSpriteImports] 已转换 " + n + " 个纹理为 Sprite 资产");
        }
    }
}
#endif
