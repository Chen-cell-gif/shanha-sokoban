using UnityEngine;
using UnityEngine.EventSystems;

namespace ShanHaiSokoban
{
    
    /// </summary>
    public class UIClickSfx : MonoBehaviour, IPointerDownHandler
    {
        public void OnPointerDown(PointerEventData eventData)
        {
            if (AudioManager.I == null) return;
            var bank = ResourceBank.I;
            if (bank == null || bank.SfxClick == null) return;
            AudioManager.I.PlaySfx(bank.SfxClick);
        }
    }
}
