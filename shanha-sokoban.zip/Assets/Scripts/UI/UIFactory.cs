﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
    
    public static class UIFactory
    {
        public static RectTransform Panel(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(1920, 1080);
            return rt;
        }

        public static Image Img(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 size,
                                Color? color = null, bool preserveAspect = false)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            var img = go.GetComponent<Image>();
            img.sprite = sprite;
            img.preserveAspect = preserveAspect;
            img.raycastTarget = false;
            if (color.HasValue) img.color = color.Value;
            return img;
        }

        public static Text Txt(Transform parent, string name, string str, int size, TextAnchor align,
                               Color? color = null, bool outline = true)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text), typeof(Outline));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            var txt = go.GetComponent<Text>();
            txt.font = ResourceBank.I.Font;
            txt.text = str;
            txt.fontSize = size;
            txt.alignment = align;
            txt.color = color ?? Color.white;
            txt.horizontalOverflow = HorizontalWrapMode.Overflow;
            txt.verticalOverflow = VerticalWrapMode.Overflow;
            txt.raycastTarget = false;
            var ol = go.GetComponent<Outline>();
            ol.effectColor = new Color(0f, 0f, 0f, 0.85f);
            ol.effectDistance = new Vector2(2, -2);
            ol.useGraphicAlpha = true;
            if (!outline) DestroyOutline(go);
            return txt;
        }

        private static void DestroyOutline(GameObject go)
        {
            var ol = go.GetComponent<Outline>();
            if (ol != null) UnityEngine.Object.Destroy(ol);
        }

       
        public static Button Btn(Transform parent, string name, Sprite sprite, Action onClick,
                                 float w, float h, string label = null, int fontSize = 30,
                                 float labelOffsetY = 0f, bool useTextStyle = false)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(w, h);
            var img = go.GetComponent<Image>();
            img.sprite = sprite;
            img.preserveAspect = !useTextStyle;
            img.color = useTextStyle ? new Color(0.13f, 0.2f, 0.14f, 0.92f) : Color.white;
            img.raycastTarget = true;
            var btn = go.GetComponent<Button>();
            go.AddComponent<UIClickSfx>();   // 点击音效
            var colors = btn.colors;
            colors.highlightedColor = new Color(1.15f, 1.15f, 1.15f, 1f);
            colors.pressedColor = new Color(0.8f, 0.8f, 0.8f, 1f);
            colors.selectedColor = Color.white;
            btn.colors = colors;
            btn.onClick.AddListener(() => { if (onClick != null) onClick(); });

            if (!string.IsNullOrEmpty(label))
            {
                var tgo = new GameObject("Label", typeof(RectTransform), typeof(Text), typeof(Outline));
                tgo.transform.SetParent(rt, false);
                var trt = tgo.GetComponent<RectTransform>();
                trt.anchorMin = Vector2.zero;
                trt.anchorMax = Vector2.one;
                trt.offsetMin = Vector2.zero;
                trt.offsetMax = Vector2.zero;
                trt.anchoredPosition = new Vector2(0f, labelOffsetY);
                var txt = tgo.GetComponent<Text>();
                txt.font = ResourceBank.I.Font;
                txt.text = label;
                txt.fontSize = fontSize;
                txt.alignment = TextAnchor.MiddleCenter;
                txt.color = Color.white;
                txt.horizontalOverflow = HorizontalWrapMode.Overflow;
                txt.verticalOverflow = VerticalWrapMode.Overflow;
                txt.raycastTarget = false;
                var ol = tgo.GetComponent<Outline>();
                ol.effectColor = new Color(0f, 0f, 0f, 0.85f);
                ol.effectDistance = new Vector2(2, -2);
            }
            return btn;
        }

     
        public static Image Background(Transform parent, Sprite sprite)
        {
            var img = Img(parent, "Background", sprite, Vector2.zero, Vector2.zero);
            img.rectTransform.anchorMin = Vector2.zero;
            img.rectTransform.anchorMax = Vector2.one;
            img.rectTransform.offsetMin = Vector2.zero;
            img.rectTransform.offsetMax = Vector2.zero;
            img.preserveAspect = false;
            return img;
        }
    }
}
