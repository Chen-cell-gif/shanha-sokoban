﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
    public class UIManager : MonoBehaviour
    {
        private GameController game;
        private LevelEditorController editor;

        private GameObject menuPanel, selectPanel, gamePanel, editorPanel, winPanel, pausePanel;
        private GameObject toastHost;
        private Text toastText;
        private Coroutine toastCoroutine;

        private RectTransform gameBoardHost, editorBoardHost;
        private Text gameTitle, gameMoves, gameBest, gameHint;
        private Text winMoves, winNextLabel;
        private Button winNextBtn;

        private readonly List<LevelEntry> levelList = new List<LevelEntry>();
        private int unlockedCount = 1;
        private readonly Dictionary<int, Sprite> btnDefaultSprites = new Dictionary<int, Sprite>();

        
        private const int LevelCount = 5;
        private const string SaveKey = "shsok_save_v3";
        private const string LegacyProgressKey = "shsok_progress_v2";
        private const string LegacyUnlockedKey = "shsok_unlocked";

        [Serializable]
        private class SaveData
        {
            public int unlocked = 1;    
            public int curLevel;        
            public string curKey;
            public int moves;
            public int pushes;
            public string[] rows;      
        }

        private SaveData saved;

       
        private GameObject dialogPanel;
        private Text dialogText, dialogName, dialogHint;
        private Image dialogPortrait;
        private Action dialogOnFinish;
        private string[] dialogLines;
        private int dialogIndex;
        private bool guideShown;

        private struct LevelEntry
        {
            public string key;
            public string name;
            public LevelData data;
            public bool isCustom;
            public int number; 
        }

        public void Init(GameController g, LevelEditorController e)
        {
            game = g;
            editor = e;

           
            LoadSave();

            BuildAllPanels();

            game.Init(gameBoardHost);
            game.SetHud(gameTitle, gameMoves, gameBest, gameHint, winPanel, winMoves);
            game.OnWin += OnGameWin;
            game.OnMoveMade += OnMoveMade;

            editor.Init(editorBoardHost, OnTestPlay, BackFromEditor, msg => ShowToast(msg));
            BindDialog();
            ShowMainMenu();
            InstallClickSfx();
        }

        // ==================== 存档 ====================

     
        private void LoadSave()
        {
            string json = PlayerPrefs.GetString(SaveKey, "");
            if (!string.IsNullOrEmpty(json))
            {
                try { saved = JsonUtility.FromJson<SaveData>(json); }
                catch (Exception ex)
                {
                    Debug.LogWarning("[存档] 解析失败：" + ex.Message);
                    saved = null;
                }
            }

            if (saved == null)
            {
                
                int legacy = Mathf.Max(PlayerPrefs.GetInt(LegacyProgressKey, 1),
                                       PlayerPrefs.GetInt(LegacyUnlockedKey, 1));
                int inferred = InferUnlockedFromBest();
                int start = Mathf.Max(Mathf.Max(legacy, inferred), 1);
                saved = new SaveData { unlocked = Mathf.Clamp(start, 1, LevelCount + 1) };
                Debug.Log("[存档] 无新存档，按历史记录推断解锁=" + saved.unlocked);
            }

            if (saved.unlocked > LevelCount)
            {
               
                ClearSave();
                Debug.Log("[存档] 五关已全通：进度清零，已通过的关卡重新锁回待解锁");
                return;
            }

            unlockedCount = Mathf.Clamp(saved.unlocked, 1, LevelCount);
            if (saved.curLevel < 1 || saved.curLevel > LevelCount ||
                saved.rows == null || saved.rows.Length == 0)
            {
                saved.curLevel = 0;   
                saved.rows = null;
            }
            Debug.Log("[存档] 读到 解锁=" + unlockedCount + " 续玩关卡=" + saved.curLevel);
        }

       
        private static int InferUnlockedFromBest()
        {
            int max = 1;
            for (int i = 1; i <= LevelCount; i++)
                if (PlayerPrefs.GetInt("shsok_best_builtin_" + i, 0) > 0)
                    max = Mathf.Max(max, i + 1);
            return max;
        }

        private void WriteSave()
        {
            if (saved == null) saved = new SaveData();
            PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(saved));
            PlayerPrefs.Save();
        }

       
        private void ClearSave()
        {
            saved = new SaveData { unlocked = 1 };
            unlockedCount = 1;
            guideShown = false;
            WriteSave();                      
            PlayerPrefs.DeleteKey(LegacyProgressKey);
            PlayerPrefs.DeleteKey(LegacyUnlockedKey);
            PlayerPrefs.Save();
        }

        private void SaveCurrentState()
        {
            if (game == null || game.Game == null || game.IsEditorTest) return;
            if (game.CurrentLevelNumber <= 0) return;  
            if (saved == null) saved = new SaveData();
            saved.unlocked = unlockedCount;
            saved.curLevel = game.CurrentLevelNumber;
            saved.curKey = game.CurrentKey;
            saved.moves = game.Game.Moves;
            saved.pushes = game.Game.Pushes;
            saved.rows = game.Game.ToLevelData(game.CurrentKey).rows;
            WriteSave();
        }

       
        private void OnMoveMade() { SaveCurrentState(); }

        // ==================== 关前引导对话框 ====================

      
        private void BindDialog()
        {
            var t = transform.Find("DialogPanel");
            if (t == null)
            {
                var boxSprite = Resources.Load<Sprite>("UI/dialog_box");
                var portraitSprite = Resources.Load<Sprite>("UI/guide_portrait");
                if (boxSprite != null)
                {
                    AddGuideDialogIfMissing(transform, boxSprite, portraitSprite);
                    t = transform.Find("DialogPanel");
                    Debug.Log("[UIManager] 场景未烘焙 DialogPanel，已用 Resources 素材运行时创建");
                }
            }
            if (t == null)
            {
                Debug.LogWarning("[UIManager] 未找到 DialogPanel，关前引导将跳过");
                return;
            }
            dialogPanel = t.gameObject;
            dialogText = FindText(t, "Box/Text");
            dialogName = FindText(t, "Box/Name");
            dialogHint = FindText(t, "Box/Hint");
            var portrait = t.Find("Box/Portrait");
            dialogPortrait = portrait != null ? portrait.GetComponent<Image>() : null;

            var btn = t.GetComponent<Button>();
            if (btn != null)
            {
                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(AdvanceDialog);
            }
            dialogPanel.SetActive(false);
        }

        private static Text FindText(Transform root, string path)
        {
            var c = root.Find(path);
            return c != null ? c.GetComponent<Text>() : null;
        }

       
        public void ShowDialog(string speaker, string[] lines, Action onFinish)
        {
            if (dialogPanel == null)
            {
                if (onFinish != null) onFinish();
                return;
            }
            dialogLines = lines ?? new string[0];
            dialogIndex = 0;
            dialogOnFinish = onFinish;
            if (dialogName != null) dialogName.text = speaker;
            dialogPanel.transform.SetAsLastSibling();
            dialogPanel.SetActive(true);
            RenderDialogLine();
        }

        private void RenderDialogLine()
        {
            if (dialogLines == null || dialogLines.Length == 0) { CloseDialog(); return; }
            if (dialogText != null)
                dialogText.text = dialogLines[Mathf.Clamp(dialogIndex, 0, dialogLines.Length - 1)];
            if (dialogHint != null)
                dialogHint.text = dialogIndex >= dialogLines.Length - 1 ? "点击开始挑战 ▶" : "点击空白处继续 ▶";
        }

        private void AdvanceDialog()
        {
            if (dialogPanel == null || dialogLines == null) return;
            dialogIndex++;
            if (dialogIndex >= dialogLines.Length) { CloseDialog(); return; }
            RenderDialogLine();
        }

        private void CloseDialog()
        {
            if (dialogPanel != null) dialogPanel.SetActive(false);
            dialogLines = null;
            var cb = dialogOnFinish;
            dialogOnFinish = null;
            if (cb != null) cb();
        }
        public void InstallClickSfx()
        {
            foreach (var b in GetComponentsInChildren<Button>(true))
            {
                if (b.GetComponent<UIClickSfx>() == null) b.gameObject.AddComponent<UIClickSfx>();
            }
        }
        public void BakeAll()
        {
            BuildAllPanels();
            foreach (var p in AllPanels())
            {
                if (p == null) continue;
                p.SetActive(true);
                MarkBaked(p);
            }
        }
        private IEnumerable<GameObject> AllPanels()
        {
            yield return menuPanel;
            yield return selectPanel;
            yield return gamePanel;
            yield return editorPanel;
            yield return winPanel;
            yield return pausePanel;
            yield return toastHost;
        }

        private static void MarkBaked(GameObject panel)
        {
            if (panel.transform.Find("_Baked") == null)
            {
                var m = new GameObject("_Baked");
                m.transform.SetParent(panel.transform, false);
            }
        }

        private static bool IsBaked(GameObject panel)
        {
            return panel != null && panel.transform.Find("_Baked") != null;
        }
       
        private void BindButton(Transform root, string path, Action action)
        {
            var t = root.Find(path);
            if (t == null)
            {
                Debug.LogWarning("[UIManager] 未找到烘焙按钮: " + root.name + "/" + path);
                return;
            }
            var b = t.GetComponent<Button>();
            if (b == null) return;
            b.onClick.AddListener(() => { if (action != null) action(); });
        }
      
        private void OnTestPlay(LevelData data)
        {
            game.StartLevel(data, "editor_test", 0, true);
            ShowGame();
        }

        // ==================== 面板构建 ====================

        private void BuildAllPanels()
        {
            
            menuPanel = FindOrCreatePanel("MainMenu");
            selectPanel = FindOrCreatePanel("LevelSelect");
            gamePanel = FindOrCreatePanel("GamePanel");
            editorPanel = FindOrCreatePanel("EditorPanel");
            winPanel = FindOrCreatePanel("WinPanel");
            pausePanel = FindOrCreatePanel("PausePanel");
            toastHost = FindOrCreatePanel("ToastHost");
            BuildMainMenu();
            BuildLevelSelect();
            BuildGamePanel();
            BuildEditorPanel();
            BuildWinPanel();
            BuildPausePanel();
            BuildToast();
        }
       
        private GameObject FindOrCreatePanel(string name)
        {
            var t = transform.Find(name);
            if (t != null) return t.gameObject;
            return UIFactory.Panel(transform, name).gameObject;
        }

        // ---------- 主菜单 ----------

        private void BuildMainMenu()
        {
            if (IsBaked(menuPanel)) { BindMainMenu(); return; }
            UIFactory.Background(menuPanel.transform, ResourceBank.I.BgMainmenu);

            // 标题
            var logo = UIFactory.Img(menuPanel.transform, "Logo", ResourceBank.I.Logo,
                                     new Vector2(0, 260), new Vector2(820, 245), Color.white, true);
            logo.color = new Color(1f, 1f, 1f, 0.96f);
            UIFactory.Txt(menuPanel.transform, "Title", "山 海 推 箱", 66, TextAnchor.MiddleCenter,
                          new Color(1f, 0.95f, 0.75f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 300);
            UIFactory.Txt(menuPanel.transform, "Sub", "—— 推箱子 · 山海机巧录 ——", 28, TextAnchor.MiddleCenter,
                          new Color(0.85f, 0.95f, 0.9f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 245);

            // 按钮组
            UIFactory.Btn(menuPanel.transform, "BtnStart", ResourceBank.I.BtnStart,
                          OnStartClicked, 240, 210, "开始游戏", 36, -120)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 10);
            UIFactory.Btn(menuPanel.transform, "BtnEditor", ResourceBank.I.BtnEditor,
                          OnEditorClicked, 240, 210, "关卡编辑器", 36, -120)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -220);
            UIFactory.Btn(menuPanel.transform, "BtnExit", ResourceBank.I.BtnExit,
                          OnExitClicked, 300, 70, "退出游戏", 30)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -400);

            menuPanel.SetActive(false);
        }

        private void BindMainMenu()
        {
            BindButton(menuPanel.transform, "BtnStart", OnStartClicked);
            BindButton(menuPanel.transform, "BtnEditor", OnEditorClicked);
            BindButton(menuPanel.transform, "BtnExit", OnExitClicked);
        }
        private void OnStartClicked()
        {
            if (unlockedCount > LevelCount)
            {
                ClearSave();
                Debug.Log("[存档] 全通后从头开始：已通过的关卡已锁回待解锁");
            }
            ShowLevelSelect();
        }

        private void OnEditorClicked() { ShowEditor(); }
        private void OnExitClicked() { Application.Quit(); }

        // ---------- 选关 ----------

        private void BuildLevelSelect()
        {
            if (IsBaked(selectPanel)) { BindLevelSelect(); return; }
            UIFactory.Background(selectPanel.transform, ResourceBank.I.BgSelect);
            UIFactory.Txt(selectPanel.transform, "Title", "选择关卡", 56, TextAnchor.MiddleCenter,
                          new Color(1f, 0.95f, 0.75f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 430);
            UIFactory.Btn(selectPanel.transform, "Back", ResourceBank.I.BtnBack,
                          OnBackToMenu, 150, 94, "返回", 26, -56)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-840, 430);
            AddLevelGridIfMissing(selectPanel.transform);
            selectPanel.SetActive(false);
        }
        public static void AddLevelGridIfMissing(Transform parent)
        {
            if (parent.Find("LevelGrid") != null) return;
            var grid = new GameObject("LevelGrid", typeof(RectTransform));
            grid.transform.SetParent(parent, false);
            var grt = grid.GetComponent<RectTransform>();
            grt.anchorMin = grt.anchorMax = new Vector2(0.5f, 0.5f);
            grt.pivot = new Vector2(0.5f, 0.5f);
            grt.anchoredPosition = new Vector2(0, 10);
            grt.sizeDelta = new Vector2(1250, 260);

            const float spacing = 230f;
            for (int i = 1; i <= 5; i++)
            {
                float x = (i - 1 - 2) * spacing;
                var btn = UIFactory.Btn(grid.transform, "Lv_builtin_" + i, LevelButtonSpriteStatic(i),
                                        null, 210, 180, "第 " + i + " 关", 26, -70);
                var brt = btn.GetComponent<RectTransform>();
                brt.anchoredPosition = new Vector2(x, 0);
                btn.interactable = true;
            }
        }

        private static Sprite LevelButtonSpriteStatic(int number)
        {
            switch (number)
            {
                case 1: return ResourceBank.I.BtnLevel1;
                case 2: return ResourceBank.I.BtnLevel2;
                case 3: return ResourceBank.I.BtnLevel3;
                case 4: return ResourceBank.I.BtnLevel4;
                default: return ResourceBank.I.BtnLevel5;
            }
        }

        private void BindLevelSelect()
        {
            BindButton(selectPanel.transform, "Back", OnBackToMenu);
        }

        private void OnBackToMenu() { ShowMainMenu(); }

        // ---------- 游戏面板 ----------

        private void BuildGamePanel()
        {
            if (IsBaked(gamePanel)) { BindGamePanel(); return; }
            UIFactory.Background(gamePanel.transform, ResourceBank.I.BgGame);
            var dim = UIFactory.Img(gamePanel.transform, "Dim", null, Vector2.zero, Vector2.zero,
                                    new Color(0f, 0f, 0f, 0.35f));

            // 顶部栏
            var top = UIFactory.Img(gamePanel.transform, "TopBar", null, new Vector2(0, 470), new Vector2(1920, 100),
                                    new Color(0.03f, 0.06f, 0.05f, 0.72f));
            UIFactory.Btn(top.transform, "Back", ResourceBank.I.BtnBack, OnBackToSelect,
                          150, 90, "返回", 24, -50)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-820, 0);
            gameTitle = UIFactory.Txt(top.transform, "Title", "", 34, TextAnchor.MiddleCenter,
                                      new Color(1f, 0.95f, 0.75f, 1f));
            gameTitle.rectTransform.anchoredPosition = new Vector2(-180, 0);
            gameMoves = UIFactory.Txt(top.transform, "Moves", "", 30, TextAnchor.MiddleCenter);
            gameMoves.rectTransform.anchoredPosition = new Vector2(300, 0);
            gameBest = UIFactory.Txt(top.transform, "Best", "", 30, TextAnchor.MiddleCenter,
                                     new Color(0.75f, 0.95f, 0.85f, 1f));
            gameBest.rectTransform.anchoredPosition = new Vector2(470, 0);

            // 棋盘宿主
            gameBoardHost = UIFactory.Img(gamePanel.transform, "BoardHost", null, new Vector2(0, -70),
                                          new Vector2(1200, 660), new Color(0f, 0f, 0f, 0.25f)).rectTransform;

            // 底部提示
            gameHint = UIFactory.Txt(gamePanel.transform, "Hint", "", 24, TextAnchor.MiddleCenter,
                                     new Color(0.85f, 0.92f, 0.85f, 0.9f));
            gameHint.rectTransform.anchoredPosition = new Vector2(0, -500);

            // 右侧操作按钮
            UIFactory.Btn(gamePanel.transform, "BtnUndo", null, OnUndoClicked, 130, 58, "撤销", 28, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(820, 200);
            UIFactory.Btn(gamePanel.transform, "BtnRestart", ResourceBank.I.BtnRestart, OnRestartClicked,
                          130, 114, "重开", 24, -58)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(820, 90);
            UIFactory.Btn(gamePanel.transform, "BtnPause", ResourceBank.I.BtnMenu, OnPauseClicked,
                          130, 114, "菜单", 24, -58)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(820, -60);

            gamePanel.SetActive(false);
        }

        private void BindGamePanel()
        {
            var top = gamePanel.transform.Find("TopBar");
            if (top != null)
            {
                gameTitle = top.Find("Title") != null ? top.Find("Title").GetComponent<Text>() : null;
                gameMoves = top.Find("Moves") != null ? top.Find("Moves").GetComponent<Text>() : null;
                gameBest = top.Find("Best") != null ? top.Find("Best").GetComponent<Text>() : null;
                BindButton(top, "Back", OnBackToSelect);
            }
            var host = gamePanel.transform.Find("BoardHost");
            gameBoardHost = host != null ? host.GetComponent<RectTransform>() : null;
            var hint = gamePanel.transform.Find("Hint");
            gameHint = hint != null ? hint.GetComponent<Text>() : null;
            BindButton(gamePanel.transform, "BtnUndo", OnUndoClicked);
            BindButton(gamePanel.transform, "BtnRestart", OnRestartClicked);
            BindButton(gamePanel.transform, "BtnPause", OnPauseClicked);
        }

        private void OnBackToSelect() { ShowLevelSelect(); }
        private void OnUndoClicked() { game.Undo(); }
        private void OnRestartClicked() { game.Restart(); }
        private void OnPauseClicked() { ShowPause(); }

        // ---------- 编辑器面板 ----------

        private void BuildEditorPanel()
        {
            if (IsBaked(editorPanel)) { BindEditorPanel(); return; }
            UIFactory.Background(editorPanel.transform, ResourceBank.I.BgGame);
            var dim = UIFactory.Img(editorPanel.transform, "Dim", null, Vector2.zero, Vector2.zero,
                                    new Color(0.02f, 0.04f, 0.03f, 0.88f));

            UIFactory.Txt(editorPanel.transform, "Title", "关卡编辑器", 44, TextAnchor.MiddleCenter,
                          new Color(1f, 0.95f, 0.75f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 470);
            UIFactory.Btn(editorPanel.transform, "Back", ResourceBank.I.BtnBack, BackFromEditor,
                          150, 94, "返回", 24, -50)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-840, 470);

            var brushLabel = UIFactory.Txt(editorPanel.transform, "Brush", "", 26, TextAnchor.MiddleCenter,
                                           new Color(0.9f, 0.95f, 0.85f, 1f));
            brushLabel.rectTransform.anchoredPosition = new Vector2(-690, 360);
            var sizeLabel = UIFactory.Txt(editorPanel.transform, "Size", "", 26, TextAnchor.MiddleCenter,
                                          new Color(0.9f, 0.95f, 0.85f, 1f));
            sizeLabel.rectTransform.anchoredPosition = new Vector2(-690, -40);

            editorBoardHost = UIFactory.Img(editorPanel.transform, "BoardHost", null, new Vector2(150, -20),
                                            new Vector2(1150, 760), new Color(0f, 0f, 0f, 0.3f)).rectTransform;

            // 左侧工具栏
            string[] names = { "墙体", "地板", "箱子", "目标", "玩家", "橡皮" };
            var brushes = (LevelEditorController.Brush[])Enum.GetValues(typeof(LevelEditorController.Brush));
            for (int i = 0; i < brushes.Length; i++)
            {
                var b = brushes[i];
                var btn = UIFactory.Btn(editorPanel.transform, "Brush_" + b, null,
                                        () => OnBrushSelected(b), 170, 54, names[i], 26, 0, true);
                btn.GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, 260 - i * 66);
                if (editor != null) editor.RegisterBrushButton(b, btn);
            }

            UIFactory.Btn(editorPanel.transform, "WPlus", null, () => OnResize(1, 0), 76, 54, "宽 +", 22, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-610, -70);
            UIFactory.Btn(editorPanel.transform, "WMinus", null, () => OnResize(-1, 0), 76, 54, "宽 -", 22, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -70);
            UIFactory.Btn(editorPanel.transform, "HPlus", null, () => OnResize(0, 1), 76, 54, "高 +", 22, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-610, -140);
            UIFactory.Btn(editorPanel.transform, "HMinus", null, () => OnResize(0, -1), 76, 54, "高 -", 22, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -140);
            UIFactory.Btn(editorPanel.transform, "Clear", null, OnEditorClear, 170, 54, "清空", 26, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -220);
            UIFactory.Btn(editorPanel.transform, "Validate", null, OnEditorValidate, 170, 54, "校验", 26, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -290);
            UIFactory.Btn(editorPanel.transform, "Save", null, OnEditorSave, 170, 54, "保存", 26, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -360);
            UIFactory.Btn(editorPanel.transform, "Test", null, OnEditorTest, 170, 54, "试玩", 26, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-690, -430);

            UIFactory.Txt(editorPanel.transform, "Hint", "左键按住拖动绘制 · 玩家仅一个 · 箱子数需等于目标数",
                          22, TextAnchor.MiddleCenter, new Color(0.8f, 0.88f, 0.8f, 0.9f))
                      .rectTransform.anchoredPosition = new Vector2(150, -500);

            if (editor != null) editor.SetPanel(editorPanel, sizeLabel, brushLabel);
            AddSaveDialogIfMissing(editorPanel.transform);
            editorPanel.SetActive(false);
        }
        public static void AddSaveDialogIfMissing(Transform editorPanel)
        {
            if (editorPanel.Find("SaveDialog") != null) return;
            var root = UIFactory.Panel(editorPanel, "SaveDialog");
            var bg = root.gameObject.AddComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0.55f);
            bg.raycastTarget = true;

            var box = UIFactory.Img(root.transform, "Box", null, Vector2.zero, new Vector2(560, 300),
                                    new Color(0.09f, 0.12f, 0.1f, 0.98f));
            UIFactory.Txt(box.transform, "Title", "保存关卡", 40, TextAnchor.MiddleCenter,
                          new Color(1f, 0.95f, 0.75f, 1f));
            UIFactory.Txt(box.transform, "Hint", "输入关卡名称", 26, TextAnchor.MiddleCenter,
                           new Color(0.8f, 0.85f, 0.8f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 40);

            var inputGo = new GameObject("Input", typeof(RectTransform), typeof(Image), typeof(InputField));
            inputGo.transform.SetParent(box.transform, false);
            var irt = inputGo.GetComponent<RectTransform>();
            irt.anchorMin = irt.anchorMax = new Vector2(0.5f, 0.5f);
            irt.sizeDelta = new Vector2(440, 60);
            irt.anchoredPosition = new Vector2(0, -20);
            inputGo.GetComponent<Image>().color = new Color(1f, 1f, 1f, 0.16f);
            var iField = inputGo.GetComponent<InputField>();
            var iTextGo = new GameObject("Text", typeof(RectTransform), typeof(Text));
            iTextGo.transform.SetParent(inputGo.transform, false);
            var itrt = iTextGo.GetComponent<RectTransform>();
            itrt.anchorMin = Vector2.zero; itrt.anchorMax = Vector2.one;
            itrt.offsetMin = new Vector2(10, 0); itrt.offsetMax = new Vector2(-10, 0);
            var iText = iTextGo.GetComponent<Text>();
            iText.font = ResourceBank.I.Font;
            iText.fontSize = 28;
            iText.alignment = TextAnchor.MiddleLeft;
            iText.color = Color.white;
            iField.textComponent = iText;

            UIFactory.Btn(box.transform, "OkBtn", null, null, 180, 58, "保存", 28, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-95, -110);
            UIFactory.Btn(box.transform, "CancelBtn", null, null, 180, 58, "取消", 28, 0, true)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(95, -110);

            root.gameObject.SetActive(false);
        }
        public static void AddExitButtonIfMissing(Transform menuPanel)
        {
            if (menuPanel == null || menuPanel.Find("BtnExit") != null) return;
            var btn = UIFactory.Btn(menuPanel, "BtnExit",
                                    ResourceBank.I != null ? ResourceBank.I.BtnExit : null,
                                    null, 300, 70, "退出游戏", 30);
            btn.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -400);
        }
        public static void FillDialogPreviewIfEmpty(Transform canvasRoot)
        {
            var dlg = canvasRoot != null ? canvasRoot.Find("DialogPanel") : null;
            if (dlg == null) return;
            var box = dlg.Find("Box");
            if (box == null) return;
            var txt = FindText(box, "Text");
            if (txt != null && string.IsNullOrEmpty(txt.text))
                txt.text = "这座机关阵的规矩很简单——把场上所有木箱，推到发光的目标格上。";
            var name = FindText(box, "Name");
            if (name != null && string.IsNullOrEmpty(name.text)) name.text = "机巧师";
            var hint = FindText(box, "Hint");
            if (hint != null && string.IsNullOrEmpty(hint.text)) hint.text = "点击空白处继续 ▶";
        }
        public static void AddGuideDialogIfMissing(Transform canvasRoot, Sprite boxSprite, Sprite portraitSprite)
        {
            if (canvasRoot == null || canvasRoot.Find("DialogPanel") != null) return;

            var root = new GameObject("DialogPanel", typeof(RectTransform), typeof(Image), typeof(Button));
            root.transform.SetParent(canvasRoot, false);
            var rt = root.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            var bg = root.GetComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0.55f);
            bg.raycastTarget = true;
            var click = root.GetComponent<Button>();
            click.transition = Selectable.Transition.None;   

            // 对话框面板（用户提供的像素图）
            var box = UIFactory.Img(root.transform, "Box", boxSprite, new Vector2(0, -190),
                                    new Vector2(1400, 640), Color.white, true);
            box.raycastTarget = false;

            // 人物立绘（驾驶室）
            var portrait = UIFactory.Img(box.transform, "Portrait", portraitSprite, new Vector2(-520, 30),
                                         new Vector2(330, 330), Color.white, true);
            portrait.raycastTarget = false;

            var nameText = UIFactory.Txt(box.transform, "Name", "机巧师", 34, TextAnchor.MiddleLeft,
                                         new Color(0.24f, 0.18f, 0.14f, 1f));
            nameText.rectTransform.sizeDelta = new Vector2(300, 50);
            nameText.rectTransform.anchoredPosition = new Vector2(-300, 210);

            var body = UIFactory.Txt(box.transform, "Text", "", 32, TextAnchor.UpperLeft,
                                     new Color(0.18f, 0.16f, 0.13f, 1f));
            body.rectTransform.sizeDelta = new Vector2(880, 300);
            body.rectTransform.anchoredPosition = new Vector2(180, 40);
            body.horizontalOverflow = HorizontalWrapMode.Wrap;
            body.verticalOverflow = VerticalWrapMode.Overflow;

            var hint = UIFactory.Txt(box.transform, "Hint", "点击空白处继续 ▶", 26, TextAnchor.MiddleRight,
                                     new Color(0.35f, 0.28f, 0.2f, 1f));
            hint.rectTransform.sizeDelta = new Vector2(420, 40);
            hint.rectTransform.anchoredPosition = new Vector2(480, -262);

            root.SetActive(true);
        }

        private void BindEditorPanel()
        {
            var host = editorPanel.transform.Find("BoardHost");
            editorBoardHost = host != null ? host.GetComponent<RectTransform>() : null;
            var sizeLabel = editorPanel.transform.Find("Size");
            var brushLabel = editorPanel.transform.Find("Brush");
            editor.SetPanel(editorPanel,
                            sizeLabel != null ? sizeLabel.GetComponent<Text>() : null,
                            brushLabel != null ? brushLabel.GetComponent<Text>() : null);

            var brushes = (LevelEditorController.Brush[])Enum.GetValues(typeof(LevelEditorController.Brush));
            foreach (var b in brushes)
            {
                var t = editorPanel.transform.Find("Brush_" + b);
                if (t == null) continue;
                var btn = t.GetComponent<Button>();
                if (btn == null) continue;
                editor.RegisterBrushButton(b, btn);
                btn.onClick.AddListener(() => OnBrushSelected(b));
            }

            BindButton(editorPanel.transform, "Back", BackFromEditor);
            BindButton(editorPanel.transform, "WPlus", () => OnResize(1, 0));
            BindButton(editorPanel.transform, "WMinus", () => OnResize(-1, 0));
            BindButton(editorPanel.transform, "HPlus", () => OnResize(0, 1));
            BindButton(editorPanel.transform, "HMinus", () => OnResize(0, -1));
            BindButton(editorPanel.transform, "Clear", OnEditorClear);
            BindButton(editorPanel.transform, "Validate", OnEditorValidate);
            BindButton(editorPanel.transform, "Save", OnEditorSave);
            BindButton(editorPanel.transform, "Test", OnEditorTest);
        }

        private void OnBrushSelected(LevelEditorController.Brush b) { editor.SelectBrush(b); }
        private void OnResize(int dw, int dh) { editor.Resize(dw, dh); }
        private void OnEditorClear() { editor.ClearAll(); }
        private void OnEditorValidate() { editor.ValidateNow(); }
        private void OnEditorSave() { editor.SaveNow(); }
        private void OnEditorTest() { editor.TestPlay(); }

        // ---------- 胜利弹层 ----------

        private void BuildWinPanel()
        {
            if (IsBaked(winPanel)) { BindWinPanel(); return; }
            var dim = winPanel.gameObject.AddComponent<Image>();
            dim.color = new Color(0f, 0f, 0f, 0.6f);
            dim.raycastTarget = true;

            var box = UIFactory.Img(winPanel.transform, "Box", null, Vector2.zero, new Vector2(640, 420),
                                    new Color(0.07f, 0.1f, 0.08f, 0.98f));
            UIFactory.Txt(box.transform, "Title", "机关归位 · 通关！", 52, TextAnchor.MiddleCenter,
                          new Color(1f, 0.92f, 0.55f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 130);
            winMoves = UIFactory.Txt(box.transform, "Moves", "", 34, TextAnchor.MiddleCenter,
                                     new Color(0.85f, 0.95f, 0.85f, 1f));
            winMoves.rectTransform.anchoredPosition = new Vector2(0, 40);

            winNextBtn = UIFactory.Btn(box.transform, "Next", ResourceBank.I.BtnDepart,
                                       OnNextClicked, 220, 190, "下一关", 32, -110);
            winNextBtn.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -120);
            winNextLabel = winNextBtn.GetComponentInChildren<Text>();

            UIFactory.Btn(box.transform, "Restart", ResourceBank.I.BtnRestart, OnRestartClicked,
                          180, 158, "重玩", 28, -90)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(-250, -160);
            UIFactory.Btn(box.transform, "Select", ResourceBank.I.BtnSelect, OnBackToSelect,
                          300, 70, "选择关卡", 28)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(250, -160);

            winPanel.SetActive(false);
        }

        private void BindWinPanel()
        {
            var box = winPanel.transform.Find("Box");
            if (box != null)
            {
                winMoves = box.Find("Moves") != null ? box.Find("Moves").GetComponent<Text>() : null;
                var nextT = box.Find("Next");
                winNextBtn = nextT != null ? nextT.GetComponent<Button>() : null;
                winNextLabel = winNextBtn != null ? winNextBtn.GetComponentInChildren<Text>() : null;
                BindButton(box, "Next", OnNextClicked);
                BindButton(box, "Restart", OnRestartClicked);
                BindButton(box, "Select", OnBackToSelect);
            }
        }

        // ---------- 暂停弹层 ----------

        private void BuildPausePanel()
        {
            if (IsBaked(pausePanel)) { BindPausePanel(); return; }
            var dim = pausePanel.gameObject.AddComponent<Image>();
            dim.color = new Color(0f, 0f, 0f, 0.62f);
            dim.raycastTarget = true;

            UIFactory.Txt(pausePanel.transform, "Title", "暂 停", 56, TextAnchor.MiddleCenter,
                          new Color(1f, 0.95f, 0.75f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 250);

            UIFactory.Btn(pausePanel.transform, "Resume", ResourceBank.I.BtnStart, OnResumeClicked,
                          220, 190, "继续", 34, -110)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 40);
            UIFactory.Btn(pausePanel.transform, "Restart", ResourceBank.I.BtnRestart, OnPauseRestart,
                          220, 190, "重开", 34, -110)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -170);
            UIFactory.Btn(pausePanel.transform, "Select", ResourceBank.I.BtnSelect, OnPauseSelect,
                          300, 70, "选择关卡", 28)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -300);
            UIFactory.Btn(pausePanel.transform, "Home", ResourceBank.I.BtnHome, OnPauseHome,
                          300, 70, "返回主菜单", 28)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -390);
            UIFactory.Btn(pausePanel.transform, "Exit", ResourceBank.I.BtnExit, OnPauseHome,
                          300, 70, "退出游戏", 28)
                      .GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -480);

            pausePanel.SetActive(false);
        }

        private void BindPausePanel()
        {
            BindButton(pausePanel.transform, "Resume", OnResumeClicked);
            BindButton(pausePanel.transform, "Restart", OnPauseRestart);
            BindButton(pausePanel.transform, "Select", OnPauseSelect);
            BindButton(pausePanel.transform, "Home", OnPauseHome);
            BindButton(pausePanel.transform, "Exit", OnPauseHome);
        }

        private void OnResumeClicked() { HidePause(); }
        private void OnPauseRestart() { HidePause(); game.Restart(); }
        private void OnPauseSelect() { HidePause(); ShowLevelSelect(); }
        private void OnPauseHome() { HidePause(); ShowMainMenu(); }

        // ---------- Toast ----------

        private void BuildToast()
        {
            if (IsBaked(toastHost)) { BindToast(); return; }
            var go = new GameObject("Toast", typeof(RectTransform), typeof(CanvasGroup));
            go.transform.SetParent(toastHost != null ? toastHost.transform : transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = new Vector2(0, 60);
            rt.sizeDelta = new Vector2(900, 70);
            toastText = UIFactory.Txt(go.transform, "Text", "", 30, TextAnchor.MiddleCenter,
                                      new Color(1f, 1f, 0.9f, 1f), true);
            go.GetComponent<CanvasGroup>().alpha = 0f;
        }

        private void BindToast()
        {
            var go = toastHost.transform.Find("Toast");
            if (go == null) return;
            var txt = go.Find("Text");
            toastText = txt != null ? txt.GetComponent<Text>() : null;
        }

        // ==================== 导航 ====================

        private void ShowOnly(GameObject panel)
        {
            menuPanel.SetActive(panel == menuPanel);
            selectPanel.SetActive(panel == selectPanel);
            gamePanel.SetActive(panel == gamePanel);
            editorPanel.SetActive(panel == editorPanel);
            winPanel.SetActive(panel == winPanel);
            pausePanel.SetActive(panel == pausePanel);
        }

        public void ShowMainMenu()
        {
            game.Stop();
            editor.Close();
            HidePause();
            ShowOnly(menuPanel);
            InstallClickSfx();
        }

        public void ShowLevelSelect()
        {
            game.Stop();
            editor.Close();
            HidePause();
           
            RebuildLevelList();
            RenderLevelButtons();
            InstallClickSfx();
            ShowOnly(selectPanel);
        }

        public void ShowGame()
        {
            ShowOnly(gamePanel);
        }

        public void ShowEditor()
        {
            game.Stop();
            HidePause();
            ShowOnly(editorPanel);
            editor.Open();
        }

        public void ShowPause()
        {
            if (!gamePanel.activeSelf) return;
            game.SetPaused(true);
            pausePanel.SetActive(true);
        }

        public void HidePause()
        {
            pausePanel.SetActive(false);
            game.SetPaused(false);
        }

        private void BackFromEditor()
        {
            editor.Close();
            ShowMainMenu();
        }

        private void OnNextClicked()
        {
            if (winPanel == null || !winPanel.activeSelf) return;
            if (game.IsEditorTest)
            {
                
                editor.ExitTest();
                HidePause();
                ShowEditor();
                ShowToast("试玩通关，可继续编辑");
                return;
            }
            int next = game.CurrentLevelNumber + 1;
            LevelEntry? e = FindBuiltin(next);
            if (e.HasValue) StartLevelEntry(e.Value);
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (pausePanel.activeSelf) HidePause();
                else if (winPanel.activeSelf) { /* 等待玩家点按钮 */ }
                else if (gamePanel.activeSelf && game.IsPlaying && game.IsEditorTest)
                {
                    // 试玩中 Esc 返回编辑器
                    editor.ExitTest();
                    ShowEditor();
                    ShowToast("已退出试玩");
                }
                else if (gamePanel.activeSelf && game.IsPlaying) ShowPause();
                else if (selectPanel.activeSelf) ShowMainMenu();
            }
        }

        // ==================== 选关 ====================

        private void RebuildLevelList()
        {
            levelList.Clear();
            for (int i = 1; i <= 5; i++)
            {
                var ta = Resources.Load<TextAsset>("Levels/builtin/level_" + i);
                if (ta == null) continue;
                try
                {
                    var data = JsonUtility.FromJson<LevelData>(ta.text);
                    if (data == null || data.rows == null || data.rows.Length == 0) continue;
                    levelList.Add(new LevelEntry
                    {
                        key = "builtin_" + i,
                        name = data.name,
                        data = data,
                        isCustom = false,
                        number = i,
                    });
                }
                catch (Exception e) { Debug.LogWarning("内置关卡解析失败: " + i + " " + e.Message); }
            }

            // 自定义关卡
            string dir = Path.Combine(Application.persistentDataPath, "custom_levels");
            if (Directory.Exists(dir))
            {
                foreach (string f in Directory.GetFiles(dir, "*.json"))
                {
                    try
                    {
                        var data = JsonUtility.FromJson<LevelData>(File.ReadAllText(f));
                        if (data == null || data.rows == null || data.rows.Length == 0) continue;
                        string baseName = Path.GetFileNameWithoutExtension(f);
                        levelList.Add(new LevelEntry
                        {
                            key = "custom_" + baseName,
                            name = data.name,
                            data = data,
                            isCustom = true,
                            number = 0,
                        });
                    }
                    catch (Exception e) { Debug.LogWarning("自定义关卡解析失败: " + f + " " + e.Message); }
                }
            }
        }

        private void RenderLevelButtons()
        {
           
            var gridRoot = selectPanel.transform.Find("LevelGrid");
            if (gridRoot == null)
            {
                var grid = new GameObject("LevelGrid", typeof(RectTransform));
                grid.transform.SetParent(selectPanel.transform, false);
                var grt = grid.GetComponent<RectTransform>();
                grt.anchorMin = grt.anchorMax = new Vector2(0.5f, 0.5f);
                grt.anchoredPosition = Vector2.zero;
                gridRoot = grid.transform;
            }
          
            for (int i = gridRoot.childCount - 1; i >= 0; i--)
            {
                var child = gridRoot.GetChild(i);
                if (child.name.StartsWith("Lv_custom")) Destroy(child.gameObject);
            }

            const int cols = 5;
            const float spacing = 230f;
            int n = levelList.Count;
            int rows = Mathf.Max(1, (n + cols - 1) / cols);
            for (int i = 0; i < n; i++)
            {
                var entry = levelList[i];
                int r = i / cols, c = i % cols;
                float x = (c - (cols - 1) * 0.5f) * spacing;
                float y = (rows - 1) * 0.5f * spacing - r * spacing + 40;

                bool locked = !entry.isCustom && entry.number > unlockedCount;
                Sprite spr = locked ? ResourceBank.I.BtnLock : LevelButtonSprite(entry.number);
               
                string label;
                if (locked) label = "待解锁";
                else if (!entry.isCustom) label = "第 " + entry.number + " 关";
                else label = string.IsNullOrEmpty(entry.name) ? entry.key : entry.name;

               
                if (!entry.isCustom && entry.number >= 1 && entry.number <= 5)
                {
                    var t = gridRoot.Find("Lv_builtin_" + entry.number);
                    if (t != null)
                    {
                      
                        t.gameObject.SetActive(true);
                        var btn = t.GetComponent<Button>();
                        if (btn != null)
                        {
                            var img = btn.GetComponent<Image>();
                            if (img != null)
                            {
                                if (!btnDefaultSprites.ContainsKey(entry.number))
                                    btnDefaultSprites[entry.number] = img.sprite;
                                if (locked) img.sprite = ResourceBank.I.BtnLock;
                                else img.sprite = btnDefaultSprites[entry.number] != null
                                                    ? btnDefaultSprites[entry.number] : spr;
                            }
                            var txtT = t.Find("Label");
                            Text labelText = txtT != null ? txtT.GetComponent<Text>() : null;
                            if (labelText == null)
                            {
                               
                                foreach (Transform ch in t)
                                {
                                    var ctxt = ch.GetComponent<Text>();
                                    if (ctxt != null) { labelText = ctxt; break; }
                                }
                            }
                            if (labelText == null)
                            {
                             
                                labelText = UIFactory.Txt(t, "Label", label, 26,
                                                          TextAnchor.MiddleCenter, Color.white);
                                var lrt = labelText.rectTransform;
                                lrt.anchorMin = lrt.anchorMax = new Vector2(0.5f, 0.5f);
                                lrt.anchoredPosition = new Vector2(0f, -70f);
                                lrt.sizeDelta = new Vector2(210, 40);
                            }
                            else labelText.text = label;
                            Debug.Log("[LvlBtn] Lv_builtin_" + entry.number +
                                      " locked=" + locked + " uc=" + unlockedCount +
                                      " label=" + label + " spr=" + (img != null && img.sprite != null ? img.sprite.name : "null"));
                            btn.interactable = !locked;
                            btn.onClick.RemoveAllListeners();
                            btn.onClick.AddListener(() =>
                            {
                                if (locked) ShowToast("通关上一关后解锁");
                                else StartLevelEntry(entry);
                            });
                        }
                        continue;
                    }
                }

              
                var btn2 = UIFactory.Btn(gridRoot, "Lv_" + entry.key, spr,
                                        () =>
                                        {
                                            if (locked) ShowToast("通关上一关后解锁");
                                            else StartLevelEntry(entry);
                                        },
                                        210, 180, label, 26, -70);
                var brt = btn2.GetComponent<RectTransform>();
                brt.anchoredPosition = new Vector2(x, y);
                btn2.interactable = !locked;
                RefreshBestLabel(brt, entry, locked);
            }
        }

        private void RefreshBestLabel(Transform btnRoot, LevelEntry entry, bool locked)
        {
            
            var bestT = btnRoot.Find("Best");
            if (bestT != null) Destroy(bestT.gameObject);
        }

        private Sprite LevelButtonSprite(int number)
        {
            switch (number)
            {
                case 1: return ResourceBank.I.BtnLevel1;
                case 2: return ResourceBank.I.BtnLevel2;
                case 3: return ResourceBank.I.BtnLevel3;
                case 4: return ResourceBank.I.BtnLevel4;
                default: return ResourceBank.I.BtnLevel5;
            }
        }

        private LevelEntry? FindBuiltin(int number)
        {
            for (int i = 0; i < levelList.Count; i++)
                if (!levelList[i].isCustom && levelList[i].number == number) return levelList[i];
            return null;
        }

        private void StartLevelEntry(LevelEntry entry)
        {
            if (!entry.isCustom && entry.number > unlockedCount)
            {
                ShowToast("该关卡尚未解锁");
                return;
            }

           
            if (!entry.isCustom && entry.number == 1 && !guideShown && dialogPanel != null)
            {
                guideShown = true;
                var data = entry.data;
                var key = entry.key;
                int number = entry.number;
                ShowOnly(selectPanel);
                ShowDialog("机巧师", new string[]
                {
                    "这座机关阵的规矩很简单——把场上所有木箱，推到发光的目标格上。",
                    "方向键或 WASD 移动，Z 撤销一步，R 重开本关。",
                    "小心脚下的陷阱格，一脚踩中，这一关就要从头再来。",
                    "加油！箱子归位，机巧自开。",
                }, () =>
                {
                    game.StartLevel(data, key, number, false);
                    ShowGame();
                    SaveCurrentState();
                });
                return;
            }

            game.StartLevel(entry.data, entry.key, entry.number, false);
            ShowGame();
            SaveCurrentState();
        }

        // ==================== 胜利与进度 ====================

        private void OnGameWin()
        {
            int moves = game.Game != null ? game.Game.Moves : 0;
            bool editorTest = game.IsEditorTest;
            if (editorTest)
            {
                editor.ExitTest();
                ShowEditor();
                ShowToast("试玩通关！");
                return;
            }

            // 最佳成绩
            string key = game.CurrentKey;
            int best = PlayerPrefs.GetInt("shsok_best_" + key, 0);
            bool newRecord = best == 0 || moves < best;
            if (newRecord)
            {
                PlayerPrefs.SetInt("shsok_best_" + key, moves);
                PlayerPrefs.Save();
            }
            if (game.CurrentLevelNumber > 0)
            {
                int nextUnlock = Mathf.Min(LevelCount + 1, game.CurrentLevelNumber + 1);
                if (unlockedCount < nextUnlock) unlockedCount = nextUnlock;
                if (saved == null) saved = new SaveData();
                saved.unlocked = unlockedCount;
                saved.curLevel = 0;
                saved.rows = null;
                WriteSave();
            }

            bool hasNext = game.CurrentLevelNumber > 0 && game.CurrentLevelNumber < 5;
            winNextBtn.interactable = hasNext;
            if (winNextLabel != null) winNextLabel.text = hasNext ? "下一关" : "已通关全部";
            game.ShowWinInfo(moves);
            winPanel.SetActive(true);
            if (newRecord) ShowToast("新纪录！" + moves + " 步");
        }

        // ==================== Toast ====================

        public void ShowToast(string msg, float duration = 1.8f)
        {
            if (toastText == null) return;
            toastText.text = msg;
            var cg = toastText.transform.parent.GetComponent<CanvasGroup>();
            cg.alpha = 1f;
            if (toastCoroutine != null) StopCoroutine(toastCoroutine);
            toastCoroutine = StartCoroutine(FadeToast(duration));
        }

        private IEnumerator FadeToast(float duration)
        {
            yield return new WaitForSeconds(duration);
            var cg = toastText.transform.parent.GetComponent<CanvasGroup>();
            float t = 0f;
            while (t < 0.4f)
            {
                t += Time.deltaTime;
                cg.alpha = 1f - t / 0.4f;
                yield return null;
            }
            cg.alpha = 0f;
        }
    }
}
