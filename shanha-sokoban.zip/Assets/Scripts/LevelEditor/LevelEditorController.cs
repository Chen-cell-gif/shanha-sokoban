﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
   
    public class LevelEditorController : MonoBehaviour
    {
        public enum Brush { Wall, Floor, Box, Target, Player, Erase }

        public bool IsEditing { get; private set; }
        public bool IsTestPlay { get; private set; }

        private Brush brush = Brush.Wall;
        private int gridW = 8, gridH = 6;
        private CellType[,] grid;
        private SokobanGame viewGame;
        private BoardView board;
        private RectTransform host;

        private readonly Dictionary<Brush, Button> brushButtons = new Dictionary<Brush, Button>();
        private Text txtSize;
        private Text txtBrush;
        private GameObject panel;
        private GameObject dialog;
        private Action<LevelData> onTestPlay;
        private Action onBack;
        private Action<string> toast;
        private InputField nameInput;

        public void Init(RectTransform boardHost, Action<LevelData> testPlayCb, Action backCb, Action<string> toastCb)
        {
            host = boardHost;
            onTestPlay = testPlayCb;
            onBack = backCb;
            toast = toastCb;
        }

        public void SetPanel(GameObject p, Text size, Text brushLabel)
        {
            panel = p;
            txtSize = size;
            txtBrush = brushLabel;
        }

        public void RegisterBrushButton(Brush b, Button btn)
        {
            brushButtons[b] = btn;
            btn.onClick.AddListener(() => SelectBrush(b));
        }

        public void SelectBrush(Brush b)
        {
            brush = b;
            UpdateBrushUi();
        }

        private void UpdateBrushUi()
        {
            foreach (var kv in brushButtons)
            {
                var img = kv.Value.GetComponent<Image>();
                img.color = kv.Key == brush
                    ? new Color(0.35f, 0.75f, 0.4f, 1f)
                    : new Color(0.13f, 0.2f, 0.14f, 0.92f);
            }
            if (txtBrush != null)
                txtBrush.text = "当前画笔：" + BrushName(brush);
        }

        private static string BrushName(Brush b)
        {
            switch (b)
            {
                case Brush.Wall: return "墙体";
                case Brush.Floor: return "地板";
                case Brush.Box: return "箱子";
                case Brush.Target: return "目标";
                case Brush.Player: return "玩家";
                default: return "橡皮";
            }
        }

        public void Open()
        {
            IsEditing = true;
            CloseSaveDialog(); 
          
            if (grid == null)
            {
                gridW = 8; gridH = 6;
                grid = MakeBlank(gridW, gridH);
                viewGame = new SokobanGame(grid);
                if (board == null)
                {
                    board = gameObject.AddComponent<BoardView>();
                    board.Setup(host);
                }
                board.LoadGame(viewGame);
                SelectBrush(Brush.Wall);
                UpdateSizeText();
            }
        }

        public void Close()
        {
            IsEditing = false;
            IsTestPlay = false;
        }

        public void ExitTest()
        {
            IsTestPlay = false;
        }

        private void Update()
        {
            if (!IsEditing || IsTestPlay || panel == null || !panel.activeSelf) return;

            Vector2Int? cell = board != null ? board.ScreenToCell(Input.mousePosition) : null;
            board.ShowHover(cell);
            if (cell.HasValue && Input.GetMouseButton(0))
            {
                Paint(cell.Value.x, cell.Value.y);
            }
        }

        private void Paint(int x, int y)
        {
            CellType t = grid[y, x];
            switch (brush)
            {
                case Brush.Wall:
                    grid[y, x] = CellType.Wall;
                    break;
                case Brush.Floor:
                    grid[y, x] = CellType.Floor;
                    break;
                case Brush.Box:
                    grid[y, x] = SokobanLevel.IsTargetCell(t) ? CellType.BoxOnTarget : CellType.Box;
                    break;
                case Brush.Target:
                    grid[y, x] = SokobanLevel.IsBoxCell(t) ? CellType.BoxOnTarget : CellType.Target;
                    break;
                case Brush.Player:
                    ClearPlayer();
                    grid[y, x] = SokobanLevel.IsTargetCell(t) ? CellType.PlayerOnTarget : CellType.Player;
                    break;
                case Brush.Erase:
                    grid[y, x] = CellType.Floor;
                    break;
            }
            viewGame.RebuildState();
            board.Refresh();
        }

        private void ClearPlayer()
        {
            for (int yy = 0; yy < gridH; yy++)
                for (int xx = 0; xx < gridW; xx++)
                    if (SokobanLevel.IsPlayerCell(grid[yy, xx]))
                        grid[yy, xx] = SokobanLevel.IsTargetCell(grid[yy, xx]) ? CellType.Target : CellType.Floor;
        }

        public void Resize(int dw, int dh)
        {
            gridW = Mathf.Clamp(gridW + dw, 3, 24);
            gridH = Mathf.Clamp(gridH + dh, 3, 18);
            var ng = MakeBlank(gridW, gridH);
            int copyW = Mathf.Min(grid.GetLength(1), gridW);
            int copyH = Mathf.Min(grid.GetLength(0), gridH);
            for (int y = 0; y < copyH; y++)
                for (int x = 0; x < copyW; x++)
                    ng[y, x] = grid[y, x];
            grid = ng;
            viewGame = new SokobanGame(grid);
            board.LoadGame(viewGame);
            UpdateSizeText();
        }

        public void ClearAll()
        {
            grid = MakeBlank(gridW, gridH);
            viewGame = new SokobanGame(grid);
            board.LoadGame(viewGame);
        }

        private void UpdateSizeText()
        {
            if (txtSize != null) txtSize.text = "尺寸 " + gridW + " × " + gridH;
        }

        private static CellType[,] MakeBlank(int w, int h)
        {
            var g = new CellType[h, w];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    g[y, x] = CellType.Floor;
            return g;
        }

        public void ValidateNow()
        {
            var issues = LevelValidator.Check(grid);
            if (issues.Count > 0)
            {
                if (toast != null) toast(issues[0]);
                return;
            }
            SolvableResult r = LevelValidator.IsSolvable(grid);
            if (toast != null) toast(LevelValidator.SolvableText(r));
        }

        public void TestPlay()
        {
            var issues = LevelValidator.Check(grid);
            if (issues.Count > 0)
            {
                if (toast != null) toast("请先通过校验：" + issues[0]);
                return;
            }
            IsTestPlay = true;
            if (onTestPlay != null)
                onTestPlay(new LevelData { name = "试玩关卡", rows = SokobanLevel.ToRows(grid) });
        }

        public void SaveNow()
        {
            var issues = LevelValidator.Check(grid);
            if (issues.Count > 0)
            {
                if (toast != null) toast("请先通过校验：" + issues[0]);
                return;
            }
            OpenSaveDialog();
        }

        private void OpenSaveDialog()
        {
            Transform t = null;
            if (panel != null)
            {
                t = panel.transform.Find("SaveDialog"); 
                if (t == null && panel.transform.parent != null)
                    t = panel.transform.parent.Find("SaveDialog");
            }
            if (t == null)
            {
                BuildSaveDialog();
            }
            dialog = t.gameObject;
            var box = t.Find("Box");
            if (box != null)
            {
                var inputT = box.Find("Input");
                nameInput = inputT != null ? inputT.GetComponent<InputField>() : null;
                var okT = box.Find("OkBtn");
                if (okT != null)
                {
                    var b = okT.GetComponent<Button>();
                    b.onClick.RemoveAllListeners();
                    b.onClick.AddListener(ConfirmSave);
                }
                var cancelT = box.Find("CancelBtn");
                if (cancelT != null)
                {
                    var b = cancelT.GetComponent<Button>();
                    b.onClick.RemoveAllListeners();
                    b.onClick.AddListener(CloseSaveDialog);
                }
            }
            dialog.SetActive(true);
        }

        private void CloseSaveDialog()
        {
            if (dialog != null) dialog.SetActive(false);
        }

        private void BuildSaveDialog()
        {
            if (dialog != null) Destroy(dialog);
            var root = UIFactory.Panel(panel.transform.parent, "SaveDialog");
            var dim = root.GetComponent<RectTransform>();
            var bg = root.gameObject.AddComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0.55f);
            bg.raycastTarget = true;

            var box = UIFactory.Img(root, "Box", null, Vector2.zero, new Vector2(560, 300),
                                    new Color(0.09f, 0.12f, 0.1f, 0.98f));
            UIFactory.Txt(box.transform, "Title", "保存关卡", 40, TextAnchor.MiddleCenter);
            UIFactory.Txt(box.transform, "Hint", "输入关卡名称", 26, TextAnchor.MiddleCenter,
                           new Color(0.8f, 0.85f, 0.8f, 1f)).rectTransform.anchoredPosition = new Vector2(0, 40);

            // 输入框
            var inputGo = new GameObject("Input", typeof(RectTransform), typeof(Image), typeof(InputField));
            inputGo.transform.SetParent(box.transform, false);
            var irt = inputGo.GetComponent<RectTransform>();
            irt.anchorMin = irt.anchorMax = new Vector2(0.5f, 0.5f);
            irt.sizeDelta = new Vector2(440, 60);
            irt.anchoredPosition = new Vector2(0, -20);
            inputGo.GetComponent<Image>().color = new Color(1f, 1f, 1f, 0.16f);
            var iField = inputGo.GetComponent<InputField>();
            var iTextGo = new GameObject("Text", typeof(RectTransform), typeof(Text));
            iTextGo.transform.SetParent(inputGo.transform, false);
            var itrt = iTextGo.GetComponent<RectTransform>();
            itrt.anchorMin = Vector2.zero; itrt.anchorMax = Vector2.one;
            itrt.offsetMin = new Vector2(10, 0); itrt.offsetMax = new Vector2(-10, 0);
            var iText = iTextGo.GetComponent<Text>();
            iText.font = ResourceBank.I.Font;
            iText.fontSize = 28;
            iText.alignment = TextAnchor.MiddleLeft;
            iText.color = Color.white;
            iField.textComponent = iText;
            nameInput = iField;

            var okBtn = UIFactory.Btn(box.transform, "OkBtn", null, () => ConfirmSave(), 180, 58, "保存", 28, 0, true);
            okBtn.GetComponent<RectTransform>().anchoredPosition = new Vector2(-95, -110);
            var cancelBtn = UIFactory.Btn(box.transform, "CancelBtn", null, () => Destroy(dialog), 180, 58, "取消", 28, 0, true);
            cancelBtn.GetComponent<RectTransform>().anchoredPosition = new Vector2(95, -110);

            dialog = root.gameObject;
        }

        private void ConfirmSave()
        {
            string name = nameInput != null ? nameInput.text.Trim() : "";
            if (string.IsNullOrEmpty(name))
            {
                if (toast != null) toast("请输入关卡名称");
                return;
            }
            string dir = Path.Combine(Application.persistentDataPath, "custom_levels");
            try { Directory.CreateDirectory(dir); }
            catch (Exception e)
            {
                if (toast != null) toast("创建目录失败：" + e.Message);
                return;
            }
            string safe = Sanitize(name);
            string path = Path.Combine(dir, safe + ".json");
            var data = new LevelData { name = name, rows = SokobanLevel.ToRows(grid) };
            try
            {
                File.WriteAllText(path, JsonUtility.ToJson(data, true));
                if (toast != null) toast("已保存：" + name);
            }
            catch (Exception e)
            {
                if (toast != null) toast("保存失败：" + e.Message);
            }
            CloseSaveDialog();
        }

        private static string Sanitize(string name)
        {
            var chars = name.ToCharArray();
            var sb = new System.Text.StringBuilder(chars.Length);
            foreach (char c in chars)
            {
                if (c == '\\' || c == '/' || c == ':' || c == '*' || c == '?' || c == '"'
                    || c == '<' || c == '>' || c == '|' || c == ' ')
                    sb.Append('_');
                else sb.Append(c);
            }
            string s = sb.ToString();
            return string.IsNullOrEmpty(s) ? "level" : s;
        }
    }
}
