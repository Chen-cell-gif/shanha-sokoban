﻿using UnityEngine;

namespace ShanHaiSokoban
{
   
    public class ResourceBank : MonoBehaviour
    {
        public static ResourceBank I { get; private set; }

        public Font Font { get; private set; }
        public Sprite BgMainmenu, BgSelect, BgGame, Logo;
        public Sprite BtnStart, BtnEditor, BtnExit, BtnBack, BtnRestart, BtnMenu, BtnDepart;
        public Sprite BtnLevel1, BtnLevel2, BtnLevel3, BtnLevel4, BtnLevel5, BtnHome, BtnSelect, BtnRestart2, BtnLock;
        public Sprite[] PlayerFrames;
        public Sprite Box, WallTile, Floor, Target, TargetOn, Sel;
        public Sprite Head, Body;
        public Sprite[] Legs;
        public Sprite Trap, Obstacle;

        
        public AudioClip SfxPush, SfxPlace, SfxWin, SfxTrap, SfxUndo, SfxClick;

        private void Awake()
        {
            EnsureLoaded();
        }

       
        public void EnsureLoaded()
        {
            I = this;

            Font = Resources.Load<Font>("Fonts/simhei");
            Debug.Assert(Font != null, "中文字体加载失败");

            BgMainmenu = Load("Art/UI/bg_mainmenu");
            BgSelect = Load("Art/UI/bg_select");
            BgGame = Load("Art/UI/bg_game");
            Logo = Load("logo");

            BtnStart = Load("Art/UI/btn_start");
            BtnEditor = Load("Art/UI/btn_editor");
            BtnExit = Load("Art/UI/btn_exit");
            BtnBack = Load("Art/UI/btn_back");
            BtnRestart = Load("Art/UI/btn_restart");
            BtnMenu = Load("Art/UI/btn_menu");
            BtnDepart = Load("Art/UI/btn_depart");
            BtnLevel1 = Load("Art/UI/btn_level1");
            BtnLevel2 = Load("Art/UI/btn_level2");
            BtnLevel3 = Load("Art/UI/btn_level3");
            BtnLevel4 = Load("Art/UI/btn_level4");
            BtnLevel5 = Load("Art/UI/btn_level5");
            BtnHome = Load("Art/UI/btn_home");
            BtnSelect = Load("Art/UI/btn_select");
            BtnRestart2 = Load("Art/UI/btn_restart2");
            BtnLock = Load("Art/UI/btn_lock");

            PlayerFrames = new Sprite[5];
            for (int i = 0; i < 5; i++) PlayerFrames[i] = Load("Art/Game/player_" + (i + 1));

            Box = Load("Art/Game/box");
            WallTile = Load("Art/Game/wall_tile");
            Floor = Load("Art/Textures/floor");
            Target = Load("Art/Textures/target");
            TargetOn = Load("Art/Textures/target_on");
            Sel = Load("Art/Textures/sel");

            
            Head = Load("Art/Game/head");
            Body = Load("Art/Game/body");
            Legs = new Sprite[5];
            for (int i = 0; i < 5; i++) Legs[i] = Load("Art/Game/leg_" + (i + 1));

            
            Trap = Load("Art/Game/trap");
            Obstacle = Load("Art/Game/obstacle");

           
            SfxPush = LoadAudio("Audio/sfx_push");
            SfxPlace = LoadAudio("Audio/sfx_place");
            SfxWin = LoadAudio("Audio/sfx_win");
            SfxTrap = LoadAudio("Audio/sfx_trap");
            SfxUndo = LoadAudio("Audio/sfx_undo");
            SfxClick = LoadAudio("Audio/sfx_click");
        }

        private AudioClip LoadAudio(string path)
        {
            var clip = Resources.Load<AudioClip>(path);
            if (clip == null)
                Debug.LogWarning("[ResourceBank] 未找到音效: " + path);
            return clip;
        }

        private Sprite Load(string path)
        {
            var spr = Resources.Load<Sprite>(path);
            if (spr == null)
            {
                Debug.LogWarning("[ResourceBank] 未找到资源: " + path);
                return null;
            }
            return spr;
        }
    }
}
