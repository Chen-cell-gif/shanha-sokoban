﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
  
    public class GameController : MonoBehaviour
    {
        public SokobanGame Game { get; private set; }
        public BoardView Board { get; private set; }
        public bool IsPlaying { get; private set; }
        public bool IsEditorTest { get; private set; }
        public string CurrentKey { get; private set; }
        public int CurrentLevelNumber { get; private set; } 

        public event Action OnWin;
        public event Action OnMoveMade;

        private RectTransform host;
        private Text txtTitle, txtMoves, txtBest, txtHint;
        private GameObject winPanel;
        private Text txtWinMoves;
        private LevelData currentData;
        private bool animating;
        private bool paused;
        private AudioSource sfxSource;

        public void Init(RectTransform boardHost)
        {
            host = boardHost;
        }

        public void SetHud(Text title, Text moves, Text best, Text hint, GameObject winPanel, Text winMoves)
        {
            txtTitle = title;
            txtMoves = moves;
            txtBest = best;
            txtHint = hint;
            this.winPanel = winPanel;
            txtWinMoves = winMoves;
            if (winPanel != null) winPanel.SetActive(false);
        }

        public void SetPaused(bool value)
        {
            paused = value;
        }

     
        private void PlaySfx(AudioClip clip)
        {
            if (clip == null) return;
            if (AudioManager.I != null)
            {
                AudioManager.I.PlaySfx(clip);
                return;
            }
            if (sfxSource == null)
            {
                sfxSource = gameObject.GetComponent<AudioSource>();
                if (sfxSource == null) sfxSource = gameObject.AddComponent<AudioSource>();
                sfxSource.playOnAwake = false;
                sfxSource.spatialBlend = 0f;
            }
            sfxSource.PlayOneShot(clip, 0.62f);
        }

      
        public void StartLevel(LevelData data, string key, int levelNumber, bool editorTest)
        {
            currentData = data;
            CurrentKey = key;
            CurrentLevelNumber = levelNumber;
            IsEditorTest = editorTest;
            Game = new SokobanGame(SokobanLevel.ParseRows(data.rows));
            if (Board == null)
            {
                Board = gameObject.AddComponent<BoardView>();
                Board.Setup(host);
            }
            Board.LoadGame(Game);
            animating = false;
            IsPlaying = true;
            RefreshHud();
            if (winPanel != null) winPanel.SetActive(false);
            if (txtHint != null)
                txtHint.text = editorTest ? "试玩模式 · Esc 返回编辑器" : "方向键 / WASD 移动 · Z 撤销 · R 重开 · Esc 菜单";
            if (OnMoveMade != null) OnMoveMade();   
        }

        public void Restart()
        {
            if (currentData == null) return;
            StartLevel(currentData, CurrentKey, CurrentLevelNumber, IsEditorTest);
        }

        public void Undo()
        {
            if (!IsPlaying || animating || paused) return;
            if (Game != null && Game.Undo())
            {
                PlaySfx(ResourceBank.I.SfxUndo);
                Board.Refresh();
                RefreshHud();
                if (OnMoveMade != null) OnMoveMade();
            }
        }

        public void Stop()
        {
            IsPlaying = false;
        }

        private void Update()
        {
            if (!IsPlaying || animating || paused) return;

            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) DoMove(0, -1);
            else if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) DoMove(0, 1);
            else if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) DoMove(-1, 0);
            else if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) DoMove(1, 0);
            else if (Input.GetKeyDown(KeyCode.Z)) Undo();
            else if (Input.GetKeyDown(KeyCode.R)) Restart();
        }

        private void DoMove(int dx, int dy)
        {
            if (Game == null || !Game.HasPlayer) return;
            int opx = Game.PlayerX, opy = Game.PlayerY;
            MoveResult res = Game.TryMove(dx, dy);
            if (res == MoveResult.Blocked || res == MoveResult.None) return;

            animating = true;
            StartCoroutine(MoveCoroutine(opx, opy, dx, dy, res));
        }

        private IEnumerator MoveCoroutine(int opx, int opy, int dx, int dy, MoveResult res)
        {
            var pFrom = new Vector2Int(opx, opy);
            var pTo = new Vector2Int(Game.PlayerX, Game.PlayerY);
            Vector2Int? bFrom = null, bTo = null;
            if (res == MoveResult.Pushed || res == MoveResult.Win)
            {
                bFrom = new Vector2Int(opx + dx, opy + dy);
                bTo = new Vector2Int(opx + dx * 2, opy + dy * 2);
               
                bool landedOnTarget = bTo.HasValue && Game.IsTargetAt(bTo.Value.x, bTo.Value.y);
                PlaySfx(landedOnTarget ? ResourceBank.I.SfxPlace : ResourceBank.I.SfxPush);
            }
            yield return Board.Slide(pFrom, pTo, bFrom, bTo, 0.12f);
            RefreshHud();
            animating = false;
            if (OnMoveMade != null) OnMoveMade();

            if (res == MoveResult.Trapped)
            {
               
                IsPlaying = false;
                PlaySfx(ResourceBank.I.SfxTrap);
                if (txtHint != null) txtHint.text = "踩中陷阱！本关重开…";
                yield return new WaitForSeconds(0.9f);
                Restart();
            }
            else if (res == MoveResult.Win)
            {
                IsPlaying = false;
                yield return new WaitForSeconds(0.25f);
                PlaySfx(ResourceBank.I.SfxWin);
                if (OnWin != null) OnWin();
            }
        }

        public void RefreshHud()
        {
            if (txtTitle != null) txtTitle.text = currentData != null ? currentData.name : "";
            if (txtMoves != null) txtMoves.text = "步数 " + (Game != null ? Game.Moves : 0);
            if (txtBest != null)
            {
                int best = BestMoves(CurrentKey);
                txtBest.text = best > 0 ? "最佳 " + best : "最佳 —";
            }
        }

        public void ShowWinInfo(int moves)
        {
            if (txtWinMoves != null) txtWinMoves.text = "本关步数 " + moves;
        }

        private int BestMoves(string key)
        {
            return PlayerPrefs.GetInt("shsok_best_" + key, 0);
        }
    }
}
