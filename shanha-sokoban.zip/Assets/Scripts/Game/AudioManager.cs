using UnityEngine;

namespace ShanHaiSokoban
{
  
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager I { get; private set; }

       
        public float SfxVolume = 0.62f;
        /// <summary>背景音乐音量：比音效更收敛，长时间循环不吵</summary>
        public float BgmVolume = 0.28f;

        private AudioSource sfxSource;
        private AudioSource bgmSource;

        /// <summary>背景音乐资源路径（Assets/Resources/Audio/bgm_main.mp3）</summary>
        private const string BgmPath = "Audio/bgm_main";

        public void Init()
        {
            I = this;
            sfxSource = gameObject.AddComponent<AudioSource>();
            sfxSource.playOnAwake = false;
            sfxSource.spatialBlend = 0f;

            bgmSource = gameObject.AddComponent<AudioSource>();
            bgmSource.playOnAwake = false;
            bgmSource.loop = true;
            bgmSource.spatialBlend = 0f;
            bgmSource.volume = BgmVolume;

            PlayBgm(Resources.Load<AudioClip>(BgmPath));
        }

        /// <summary>播放背景音乐；主菜单、选关、关前介绍、对局全程循环同一首</summary>
        public void PlayBgm(AudioClip clip)
        {
            if (bgmSource == null) return;
            if (clip == null)
            {
                Debug.LogWarning("[BGM] 未找到 " + BgmPath + "，背景音乐跳过");
                return;
            }
            bgmSource.clip = clip;
            bgmSource.loop = true;
            bgmSource.volume = BgmVolume;
            bgmSource.Play();
            Debug.Log("[BGM] 开始播放 " + clip.name + "，音量 " + BgmVolume);
        }

       
        public void PlaySfx(AudioClip clip)
        {
            if (clip == null || sfxSource == null) return;
            sfxSource.PlayOneShot(clip, SfxVolume);
        }
    }
}
