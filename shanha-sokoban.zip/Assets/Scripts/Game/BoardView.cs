﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
    
    public class BoardView : MonoBehaviour
    {
        public SokobanGame Game { get; private set; }

        private RectTransform boardRect;   
        private RectTransform cellLayer;    
        private RectTransform contentLayer; 
        private RectTransform hostRect;

        private Image[,] floors;
        private Image[,] walls;
        private Image[,] targets;
        private Image[,] obstacles;
        private Image[,] trapMarks;
        private readonly List<Image> boxImages = new List<Image>();
        private RectTransform playerRoot;  
        private Image playerBody;          
        private Image playerLeg;           
        private int facing = 1;            
        private Image selImage;

        private float cell;
        private const int MaxBoxImages = 24;

       
        public void Setup(RectTransform host)
        {
            hostRect = host;
            var go = new GameObject("Board", typeof(RectTransform));
            go.transform.SetParent(host, false);
            boardRect = go.GetComponent<RectTransform>();
            boardRect.anchorMin = boardRect.anchorMax = new Vector2(0.5f, 0.5f);
            boardRect.pivot = new Vector2(0.5f, 0.5f);
            boardRect.anchoredPosition = Vector2.zero;

            var cl = new GameObject("CellLayer", typeof(RectTransform));
            cl.transform.SetParent(boardRect, false);
            cellLayer = cl.GetComponent<RectTransform>();
            cellLayer.anchorMin = cellLayer.anchorMax = new Vector2(0.5f, 0.5f);
            cellLayer.pivot = new Vector2(0.5f, 0.5f);
            cellLayer.anchoredPosition = Vector2.zero;

            var ct = new GameObject("ContentLayer", typeof(RectTransform));
            ct.transform.SetParent(boardRect, false);
            contentLayer = ct.GetComponent<RectTransform>();
            contentLayer.anchorMin = contentLayer.anchorMax = new Vector2(0.5f, 0.5f);
            contentLayer.pivot = new Vector2(0.5f, 0.5f);
            contentLayer.anchoredPosition = Vector2.zero;

            
            selImage = MakeImage(contentLayer, "Sel", ResourceBank.I.Sel, new Vector2(0.5f, 0.5f));
            selImage.rectTransform.sizeDelta = new Vector2(64, 64);
            selImage.enabled = false;
        }
        
        public void LoadGame(SokobanGame game)
        {
            Game = game;
            Rebuild();
        }
        public void Rebuild()
        {
            if (Game == null) return;
            ClearChildren(cellLayer);
            ClearChildren(contentLayer);
            floors = null; walls = null; targets = null; obstacles = null; trapMarks = null;
            boxImages.Clear();
            selImage = null;
            playerRoot = null;
            playerBody = null; playerLeg = null;
            facing = 1;

            int w = Game.Width, h = Game.Height;
            float hostW = hostRect.rect.width > 10 ? hostRect.rect.width : 800;
            float hostH = hostRect.rect.height > 10 ? hostRect.rect.height : 600;
            cell = Mathf.Min(hostW / w, hostH / h);
            cell = Mathf.Clamp(cell, 40f, 110f);

            boardRect.sizeDelta = new Vector2(w * cell, h * cell);

            floors = new Image[h, w];
            walls = new Image[h, w];
            targets = new Image[h, w];
            obstacles = new Image[h, w];
            trapMarks = new Image[h, w];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    Vector2 pos = CellToPos(x, y);
                    var cellRt = new GameObject("Cell_" + x + "_" + y, typeof(RectTransform));
                    cellRt.transform.SetParent(cellLayer, false);
                    var rt = cellRt.GetComponent<RectTransform>();
                    rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                    rt.pivot = new Vector2(0.5f, 0.5f);
                    rt.anchoredPosition = pos;
                    rt.sizeDelta = new Vector2(cell, cell);

                    floors[y, x] = MakeImage(rt, "Floor", ResourceBank.I.Floor, Vector2.one * 0.5f);
                    floors[y, x].rectTransform.sizeDelta = new Vector2(cell + 1, cell + 1);

                    walls[y, x] = MakeImage(rt, "Wall", ResourceBank.I.WallTile, Vector2.one * 0.5f);
                    walls[y, x].rectTransform.sizeDelta = new Vector2(cell + 1, cell + 1);
                    walls[y, x].enabled = false;

                    obstacles[y, x] = MakeImage(rt, "Obstacle", ResourceBank.I.Obstacle, Vector2.one * 0.5f);
                    obstacles[y, x].rectTransform.sizeDelta = new Vector2(cell * 0.95f, cell * 0.95f);
                    obstacles[y, x].enabled = false;

                    targets[y, x] = MakeImage(rt, "Target", ResourceBank.I.Target, Vector2.one * 0.5f);
                    targets[y, x].rectTransform.sizeDelta = new Vector2(cell * 0.62f, cell * 0.62f);
                    targets[y, x].enabled = false;

                    trapMarks[y, x] = MakeImage(rt, "Trap", ResourceBank.I.Trap, Vector2.one * 0.5f);
                    trapMarks[y, x].rectTransform.sizeDelta = new Vector2(cell * 0.85f, cell * 0.85f);
                    trapMarks[y, x].enabled = false;
                }
            }

            // 实体层：固定数量的箱子图 + 玩家图
            for (int i = 0; i < MaxBoxImages; i++)
            {
                var img = MakeImage(contentLayer, "Box_" + i, ResourceBank.I.Box, Vector2.one * 0.5f);
                img.rectTransform.sizeDelta = new Vector2(cell * 0.92f, cell * 0.92f);
                img.enabled = false;
                boxImages.Add(img);
            }
            // 玩家两部件：腿(底) → 身，腿部走路动画
            var proot = new GameObject("Player", typeof(RectTransform));
            proot.transform.SetParent(contentLayer, false);
            playerRoot = proot.GetComponent<RectTransform>();
            playerRoot.anchorMin = playerRoot.anchorMax = new Vector2(0.5f, 0.5f);
            playerRoot.pivot = new Vector2(0.5f, 0.5f);
            playerRoot.anchoredPosition = Vector2.zero;
            playerRoot.sizeDelta = new Vector2(cell, cell);

            playerLeg = MakeImage(playerRoot, "Leg", ResourceBank.I.Legs[0], Vector2.one * 0.5f);
            playerLeg.rectTransform.anchoredPosition = new Vector2(0f, -cell * 0.42f);
            playerLeg.rectTransform.sizeDelta = new Vector2(cell * 0.78f, cell * 0.78f);
            playerLeg.enabled = false;

            playerBody = MakeImage(playerRoot, "Body", ResourceBank.I.Body, Vector2.one * 0.5f);
            playerBody.rectTransform.anchoredPosition = new Vector2(0f, cell * 0.02f);
            playerBody.rectTransform.sizeDelta = new Vector2(cell * 0.88f, cell * 0.88f);
            playerBody.enabled = false;

           
            selImage = MakeImage(contentLayer, "Sel", ResourceBank.I.Sel, Vector2.one * 0.5f);
            selImage.rectTransform.sizeDelta = new Vector2(64, 64);
            selImage.enabled = false;

            Refresh();
        }

       
        public void Refresh()
        {
            if (Game == null || floors == null) return;
            int w = Game.Width, h = Game.Height;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    CellType t = Game.Grid[y, x];
                    bool isWall = t == CellType.Wall;
                    bool isObstacle = t == CellType.Obstacle;
                    bool isTarget = Game.IsTargetAt(x, y);
                    floors[y, x].enabled = !isWall && !isObstacle;
                    walls[y, x].enabled = isWall;
                    obstacles[y, x].enabled = isObstacle;
                    targets[y, x].enabled = isTarget && !isWall && !isObstacle;
                    trapMarks[y, x].enabled = Game.IsTrapAt(x, y) && !isWall && !isObstacle;
                    if (isTarget && !isWall && !isObstacle)
                    {
                        bool occupied = t == CellType.BoxOnTarget || t == CellType.PlayerOnTarget;
                        targets[y, x].sprite = occupied ? ResourceBank.I.TargetOn : ResourceBank.I.Target;
                    }
                }
            }

            // 箱子
            var boxCells = new List<Vector2Int>();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    if (SokobanLevel.IsBoxCell(Game.Grid[y, x])) boxCells.Add(new Vector2Int(x, y));

            for (int i = 0; i < boxImages.Count; i++)
            {
                if (i < boxCells.Count)
                {
                    boxImages[i].enabled = true;
                    boxImages[i].rectTransform.anchoredPosition = CellToPos(boxCells[i].x, boxCells[i].y);
                }
                else boxImages[i].enabled = false;
            }

          
            bool hasPlayer = Game.HasPlayer;
            playerLeg.enabled = hasPlayer;
            playerBody.enabled = hasPlayer;
            if (hasPlayer)
            {
                playerRoot.anchoredPosition = CellToPos(Game.PlayerX, Game.PlayerY);
                playerLeg.sprite = ResourceBank.I.Legs[0];
                ApplyFacing();
            }
        }

       
        public Vector2 CellToPos(int x, int y)
        {
            return new Vector2((x - (Game.Width - 1) * 0.5f) * cell,
                               ((Game.Height - 1) * 0.5f - y) * cell);
        }

        public float CellSize { get { return cell; } }

        public RectTransform BoardRect { get { return boardRect; } }

        
        public Vector2Int? ScreenToCell(Vector2 screenPos)
        {
            if (boardRect == null || Game == null) return null;
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(boardRect, screenPos, null, out local))
                return null;
            int x = Mathf.FloorToInt(local.x / cell + Game.Width * 0.5f);
            int y = Mathf.FloorToInt(Game.Height * 0.5f - local.y / cell);
            if (x < 0 || y < 0 || x >= Game.Width || y >= Game.Height) return null;
            return new Vector2Int(x, y);
        }

       
        public void ShowHover(Vector2Int? c)
        {
            if (selImage == null) return;
            if (c.HasValue)
            {
                selImage.enabled = true;
                selImage.rectTransform.anchoredPosition = CellToPos(c.Value.x, c.Value.y);
                selImage.rectTransform.sizeDelta = new Vector2(cell, cell);
            }
            else selImage.enabled = false;
        }

        
       
        /// </summary>
        public IEnumerator Slide(Vector2Int playerFrom, Vector2Int playerTo,
                                 Vector2Int? boxFrom, Vector2Int? boxTo,
                                 float duration)
        {
            Vector2 pFrom = CellToPos(playerFrom.x, playerFrom.y);
            Vector2 pTo = CellToPos(playerTo.x, playerTo.y);
            Vector2 bFrom = boxFrom.HasValue ? CellToPos(boxFrom.Value.x, boxFrom.Value.y) : Vector2.zero;
            Vector2 bTo = boxTo.HasValue ? CellToPos(boxTo.Value.x, boxTo.Value.y) : Vector2.zero;

            Image boxImg = null;
            if (boxFrom.HasValue)
            {
                foreach (var img in boxImages)
                {
                    if (!img.enabled) continue;
                    if (Vector2.Distance(img.rectTransform.anchoredPosition, bFrom) < 1f)
                    { boxImg = img; break; }
                }
            }

            if (playerTo.x != playerFrom.x) facing = playerTo.x > playerFrom.x ? 1 : -1;
            ApplyFacing();

            playerRoot.anchoredPosition = pFrom;
            if (boxImg != null) boxImg.rectTransform.anchoredPosition = bFrom;

            var legs = ResourceBank.I.Legs;
            float t = 0f;
            while (t < duration)
            {
                t += Time.deltaTime;
                float k = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(t / duration));
                playerRoot.anchoredPosition = Vector2.Lerp(pFrom, pTo, k);
                if (boxImg != null) boxImg.rectTransform.anchoredPosition = Vector2.Lerp(bFrom, bTo, k);
                int fi = Mathf.Min(legs.Length - 1, Mathf.FloorToInt(k * legs.Length));
                playerLeg.sprite = legs[fi];
                yield return null;
            }
            playerRoot.anchoredPosition = pTo;
            if (boxImg != null) boxImg.rectTransform.anchoredPosition = bTo;
            Refresh();
        }

     
        private void ApplyFacing()
        {
            if (playerRoot == null) return;
            var sx = (float)facing;
            playerBody.rectTransform.localScale = new Vector3(sx, 1f, 1f);
            playerLeg.rectTransform.localScale = new Vector3(sx, 1f, 1f);
        }

        private Image MakeImage(Transform parent, string name, Sprite sprite, Vector2 pivot)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = pivot;
            rt.anchoredPosition = Vector2.zero;
            var img = go.GetComponent<Image>();
            img.sprite = sprite;
            img.preserveAspect = true;
            img.raycastTarget = false;
            return img;
        }

        private static void ClearChildren(Transform parent)
        {
            for (int i = parent.childCount - 1; i >= 0; i--)
                Destroy(parent.GetChild(i).gameObject);
        }
    }
}
