﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ShanHaiSokoban
{
    
    public class Bootstrap : MonoBehaviour
    {
        private void Awake()
        {
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;

            var resBank = gameObject.AddComponent<ResourceBank>();
            // 统一音效音量管理
            gameObject.AddComponent<AudioManager>().Init();

            EnsureEventSystem();

           
            var existing = FindObjectOfType<Canvas>();
            var canvasGo = existing != null ? existing.gameObject : null;
            if (canvasGo == null)
            {
                canvasGo = new GameObject("UICanvas", typeof(RectTransform), typeof(Canvas),
                                          typeof(CanvasScaler), typeof(GraphicRaycaster));
                canvasGo.transform.SetParent(transform, false);
                var canvas = canvasGo.GetComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.pixelPerfect = false;
                var scaler = canvasGo.GetComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scaler.matchWidthOrHeight = 0.5f;
            }

            var ui = canvasGo.AddComponent<UIManager>();
            var gameCtrl = gameObject.AddComponent<GameController>();
            var editorCtrl = gameObject.AddComponent<LevelEditorController>();

            ui.Init(gameCtrl, editorCtrl);
        }

        private static void EnsureEventSystem()
        {
            if (FindObjectOfType<EventSystem>() != null) return;
            var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            es.transform.SetParent(null);
        }
    }
}
